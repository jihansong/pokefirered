static const struct SpriteFrameImage sPicTable_BrendanNormal[] = {
    overworld_ascending_frames(gObjectEventPic_BrendanNormalRunning, 2, 4),
};

static const struct SpriteFrameImage sPicTable_BrendanMachBike[] = {
    overworld_ascending_frames(gObjectEventPic_BrendanMachBike, 4, 4),
};

static const struct SpriteFrameImage sPicTable_BrendanAcroBike[] = {
    overworld_ascending_frames(gObjectEventPic_BrendanAcroBike, 4, 4),
};

static const struct SpriteFrameImage sPicTable_BrendanSurfing[] = {
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 3),
    overworld_frame(gObjectEventPic_BrendanSurfing, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_BrendanUnderwater[] = {
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanUnderwater, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_BrendanFieldMove[] = {
    overworld_ascending_frames(gObjectEventPic_BrendanFieldMove, 4, 4),
};

static const struct SpriteFrameImage sPicTable_QuintyPlump[] = {
    overworld_ascending_frames(gObjectEventPic_QuintyPlump, 4, 4),
};

static const struct SpriteFrameImage sPicTable_NinjaBoy[] = {
    overworld_ascending_frames(gObjectEventPic_NinjaBoy, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Twin[] = {
    overworld_ascending_frames(gObjectEventPic_Twin, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Boy1[] = {
    overworld_ascending_frames(gObjectEventPic_Boy1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Girl1[] = {
    overworld_ascending_frames(gObjectEventPic_Girl1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Boy2[] = {
    overworld_ascending_frames(gObjectEventPic_Boy2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Girl2[] = {
    overworld_ascending_frames(gObjectEventPic_Girl2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_LittleBoy[] = {
    overworld_ascending_frames(gObjectEventPic_LittleBoy, 2, 2),
};

static const struct SpriteFrameImage sPicTable_LittleGirl[] = {
    overworld_ascending_frames(gObjectEventPic_LittleGirl, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Boy3[] = {
    overworld_ascending_frames(gObjectEventPic_Boy3, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Girl3[] = {
    overworld_ascending_frames(gObjectEventPic_Girl3, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RichBoy[] = {
    overworld_ascending_frames(gObjectEventPic_RichBoy, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Woman1[] = {
    overworld_ascending_frames(gObjectEventPic_Woman1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_FatMan[] = {
    overworld_ascending_frames(gObjectEventPic_FatMan, 2, 4),
};

static const struct SpriteFrameImage sPicTable_PokefanF[] = {
    overworld_ascending_frames(gObjectEventPic_PokefanF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Man1[] = {
    overworld_ascending_frames(gObjectEventPic_Man1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Woman2[] = {
    overworld_ascending_frames(gObjectEventPic_Woman2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_ExpertM[] = {
    overworld_ascending_frames(gObjectEventPic_ExpertM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_ExpertF[] = {
    overworld_ascending_frames(gObjectEventPic_ExpertF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Man2[] = {
    overworld_ascending_frames(gObjectEventPic_Man2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Woman3[] = {
    overworld_ascending_frames(gObjectEventPic_Woman3, 2, 4),
};

static const struct SpriteFrameImage sPicTable_PokefanM[] = {
    overworld_ascending_frames(gObjectEventPic_PokefanM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Woman4[] = {
    overworld_ascending_frames(gObjectEventPic_Woman4, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Cook[] = {
    overworld_frame(gObjectEventPic_Cook, 2, 4, 0),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 1),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 2),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 0),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 0),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 1),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 1),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 2),
    overworld_frame(gObjectEventPic_Cook, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_LinkReceptionist[] = {
    overworld_ascending_frames(gObjectEventPic_LinkReceptionist, 2, 4),
};

static const struct SpriteFrameImage sPicTable_OldMan[] = {
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_OldWoman[] = {
    overworld_ascending_frames(gObjectEventPic_OldWoman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Camper[] = {
    overworld_ascending_frames(gObjectEventPic_Camper, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Picnicker[] = {
    overworld_ascending_frames(gObjectEventPic_Picnicker, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Man3[] = {
    overworld_ascending_frames(gObjectEventPic_Man3, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Woman5[] = {
    overworld_ascending_frames(gObjectEventPic_Woman5, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Youngster[] = {
    overworld_ascending_frames(gObjectEventPic_Youngster, 2, 4),
};

static const struct SpriteFrameImage sPicTable_BugCatcher[] = {
    overworld_ascending_frames(gObjectEventPic_BugCatcher, 2, 4),
};

static const struct SpriteFrameImage sPicTable_PsychicM[] = {
    overworld_ascending_frames(gObjectEventPic_PsychicM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_SchoolKidM[] = {
    overworld_ascending_frames(gObjectEventPic_SchoolKidM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Maniac[] = {
    overworld_ascending_frames(gObjectEventPic_Maniac, 2, 4),
};

static const struct SpriteFrameImage sPicTable_HexManiac[] = {
    overworld_ascending_frames(gObjectEventPic_HexManiac, 2, 4),
};

static const struct SpriteFrameImage sPicTable_SwimmerM[] = {
    overworld_ascending_frames(gObjectEventPic_SwimmerM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_SwimmerF[] = {
    overworld_ascending_frames(gObjectEventPic_SwimmerF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_BlackBelt[] = {
    overworld_ascending_frames(gObjectEventPic_BlackBelt, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Beauty[] = {
    overworld_ascending_frames(gObjectEventPic_Beauty, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Scientist1[] = {
    overworld_ascending_frames(gObjectEventPic_Scientist1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Lass[] = {
    overworld_ascending_frames(gObjectEventPic_Lass, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Gentleman[] = {
    overworld_ascending_frames(gObjectEventPic_Gentleman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Sailor[] = {
    overworld_ascending_frames(gObjectEventPic_Sailor, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Fisherman[] = {
    overworld_ascending_frames(gObjectEventPic_Fisherman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RunningTriathleteM[] = {
    overworld_ascending_frames(gObjectEventPic_RunningTriathleteM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RunningTriathleteF[] = {
    overworld_ascending_frames(gObjectEventPic_RunningTriathleteF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_TuberF[] = {
    overworld_ascending_frames(gObjectEventPic_TuberF, 2, 2),
};

static const struct SpriteFrameImage sPicTable_TuberM[] = {
    overworld_ascending_frames(gObjectEventPic_TuberM, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Hiker[] = {
    overworld_ascending_frames(gObjectEventPic_Hiker, 2, 4),
};

static const struct SpriteFrameImage sPicTable_CyclingTriathleteM[] = {
    overworld_ascending_frames(gObjectEventPic_CyclingTriathleteM, 4, 4),
};

static const struct SpriteFrameImage sPicTable_CyclingTriathleteF[] = {
    overworld_ascending_frames(gObjectEventPic_CyclingTriathleteF, 4, 4),
};

static const struct SpriteFrameImage sPicTable_Nurse[] = {
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 3),
};

static const struct SpriteFrameImage sPicTable_ProfBirch[] = {
    overworld_ascending_frames(gObjectEventPic_ProfBirch, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Man4[] = {
    overworld_ascending_frames(gObjectEventPic_Man4, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Man5[] = {
    overworld_ascending_frames(gObjectEventPic_Man5, 2, 4),
};

static const struct SpriteFrameImage sPicTable_ReporterM[] = {
    overworld_ascending_frames(gObjectEventPic_ReporterM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_ReporterF[] = {
    overworld_ascending_frames(gObjectEventPic_ReporterF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MauvilleOldMan1[] = {
    overworld_ascending_frames(gObjectEventPic_MauvilleOldMan1, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MauvilleOldMan2[] = {
    overworld_ascending_frames(gObjectEventPic_MauvilleOldMan2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_UnusedNatuDoll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedNatuDoll),
};

static const struct SpriteFrameImage sPicTable_UnusedMagnemiteDoll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedMagnemiteDoll),
};

static const struct SpriteFrameImage sPicTable_UnusedSquirtleDoll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedSquirtleDoll),
};

static const struct SpriteFrameImage sPicTable_UnusedWooperDoll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedWooperDoll),
};

static const struct SpriteFrameImage sPicTable_UnusedPikachuDoll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedPikachuDoll),
};

static const struct SpriteFrameImage sPicTable_UnusedPorygon2Doll[] = {
    obj_frame_tiles(gObjectEventPic_UnusedPorygon2Doll),
};

static const struct SpriteFrameImage sPicTable_CuttableTree[] = {
    overworld_ascending_frames(gObjectEventPic_CuttableTree, 2, 2),
};

static const struct SpriteFrameImage sPicTable_MartEmployee[] = {
    overworld_ascending_frames(gObjectEventPic_MartEmployee, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RooftopSaleWoman[] = {
    overworld_ascending_frames(gObjectEventPic_RooftopSaleWoman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Teala[] = {
    overworld_ascending_frames(gObjectEventPic_Teala, 2, 4),
};

static const struct SpriteFrameImage sPicTable_BreakableRock[] = {
    overworld_ascending_frames(gObjectEventPic_BreakableRock, 2, 2),
};

static const struct SpriteFrameImage sPicTable_PushableBoulder[] = {
    obj_frame_tiles(gObjectEventPic_PushableBoulder),
};

static const struct SpriteFrameImage sPicTable_MrBrineysBoat[] = {
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 2),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 2),
    overworld_frame(gObjectEventPic_MrBrineysBoat, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Truck[] = {
    obj_frame_tiles(gObjectEventPic_Truck),
};

static const struct SpriteFrameImage sPicTable_VigorothCarryingBox[] = {
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 0),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 0),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 0),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 1),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 2),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 1),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 2),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 1),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_VigorothFacingAway[] = {
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 3),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 3),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 3),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
    overworld_frame(gObjectEventPic_VigorothMover, 4, 4, 4),
};

static const struct SpriteFrameImage sPicTable_BirchsBag[] = {
    obj_frame_tiles(gObjectEventPic_BirchsBag),
};

static const struct SpriteFrameImage sPicTable_EnemyZigzagoon[] = {
    overworld_ascending_frames(gObjectEventPic_EnemyZigzagoon, 4, 4),
};

static const struct SpriteFrameImage sPicTable_Artist[] = {
    overworld_ascending_frames(gObjectEventPic_Artist, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MayNormal[] = {
    overworld_ascending_frames(gObjectEventPic_MayNormalRunning, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MayMachBike[] = {
    overworld_ascending_frames(gObjectEventPic_MayMachBike, 4, 4),
};

static const struct SpriteFrameImage sPicTable_MayAcroBike[] = {
    overworld_ascending_frames(gObjectEventPic_MayAcroBike, 4, 4),
};

static const struct SpriteFrameImage sPicTable_MaySurfing[] = {
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 0),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 2),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 4),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 1),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 3),
    overworld_frame(gObjectEventPic_MaySurfing, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_MayUnderwater[] = {
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 2),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 0),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 1),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 2),
    overworld_frame(gObjectEventPic_MayUnderwater, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_MayFieldMove[] = {
    overworld_ascending_frames(gObjectEventPic_MayFieldMove, 4, 4),
};

static const struct SpriteFrameImage sPicTable_Cameraman[] = {
    overworld_ascending_frames(gObjectEventPic_Cameraman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MovingBox[] = {
    obj_frame_tiles(gObjectEventPic_MovingBox),
};

static const struct SpriteFrameImage sPicTable_CableCar[] = {
    obj_frame_tiles(gObjectEventPic_CableCar),
};

static const struct SpriteFrameImage sPicTable_Scientist2[] = {
    overworld_ascending_frames(gObjectEventPic_Scientist2, 2, 4),
};

static const struct SpriteFrameImage sPicTable_DevonEmployee[] = {
    overworld_ascending_frames(gObjectEventPic_DevonEmployee, 2, 4),
};

static const struct SpriteFrameImage sPicTable_AquaMemberM[] = {
    overworld_ascending_frames(gObjectEventPic_AquaMemberM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_AquaMemberF[] = {
    overworld_ascending_frames(gObjectEventPic_AquaMemberF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MagmaMemberM[] = {
    overworld_ascending_frames(gObjectEventPic_MagmaMemberM, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MagmaMemberF[] = {
    overworld_ascending_frames(gObjectEventPic_MagmaMemberF, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Sidney[] = {
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sidney, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Phoebe[] = {
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 2),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 2),
    overworld_frame(gObjectEventPic_Phoebe, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Glacia[] = {
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 2),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 2),
    overworld_frame(gObjectEventPic_Glacia, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Drake[] = {
    overworld_frame(gObjectEventPic_Drake, 2, 4, 0),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 1),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 2),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 0),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 0),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 1),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 1),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 2),
    overworld_frame(gObjectEventPic_Drake, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Roxanne[] = {
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 2),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 2),
    overworld_frame(gObjectEventPic_Roxanne, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Brawly[] = {
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brawly, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Wattson[] = {
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 2),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 2),
    overworld_frame(gObjectEventPic_Wattson, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Flannery[] = {
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 2),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 2),
    overworld_frame(gObjectEventPic_Flannery, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Norman[] = {
    overworld_ascending_frames(gObjectEventPic_Norman, 2, 4),
    overworld_frame(gObjectEventPic_Norman, 2, 4, 6),
    overworld_frame(gObjectEventPic_Norman, 2, 4, 7),
    overworld_frame(gObjectEventPic_Norman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Winona[] = {
    overworld_frame(gObjectEventPic_Winona, 2, 4, 0),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 1),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 2),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 0),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 0),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 1),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 1),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 2),
    overworld_frame(gObjectEventPic_Winona, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Liza[] = {
    overworld_frame(gObjectEventPic_Liza, 2, 4, 0),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 1),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 2),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 0),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 0),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 1),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 1),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 2),
    overworld_frame(gObjectEventPic_Liza, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Tate[] = {
    overworld_frame(gObjectEventPic_Tate, 2, 4, 0),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 1),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 2),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 0),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 0),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 1),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 1),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 2),
    overworld_frame(gObjectEventPic_Tate, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Wallace[] = {
    overworld_ascending_frames(gObjectEventPic_Wallace, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Steven[] = {
    overworld_ascending_frames(gObjectEventPic_Steven, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Wally[] = {
    overworld_ascending_frames(gObjectEventPic_Wally, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RubySapphireLittleBoy[] = {
    overworld_ascending_frames(gObjectEventPic_RubySapphireLittleBoy, 2, 2),
};

static const struct SpriteFrameImage sPicTable_BrendanFishing[] = {
    overworld_ascending_frames(gObjectEventPic_BrendanFishing, 4, 4),
};

static const struct SpriteFrameImage sPicTable_MayFishing[] = {
    overworld_ascending_frames(gObjectEventPic_MayFishing, 4, 4),
};

static const struct SpriteFrameImage sPicTable_HotSpringsOldWoman[] = {
    overworld_ascending_frames(gObjectEventPic_HotSpringsOldWoman, 2, 4),
};

static const struct SpriteFrameImage sPicTable_SSTidal[] = {
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
    obj_frame_tiles(gObjectEventPic_SSTidal),
};

static const struct SpriteFrameImage sPicTable_SubmarineShadow[] = {
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
    obj_frame_tiles(gObjectEventPic_SubmarineShadow),
};

static const struct SpriteFrameImage sPicTable_PichuDoll[] = {
    obj_frame_tiles(gObjectEventPic_PichuDoll),
};

static const struct SpriteFrameImage sPicTable_PikachuDoll[] = {
    obj_frame_tiles(gObjectEventPic_PikachuDoll),
};

static const struct SpriteFrameImage sPicTable_MarillDoll[] = {
    obj_frame_tiles(gObjectEventPic_MarillDoll),
};

static const struct SpriteFrameImage sPicTable_TogepiDoll[] = {
    obj_frame_tiles(gObjectEventPic_TogepiDoll),
};

static const struct SpriteFrameImage sPicTable_CyndaquilDoll[] = {
    obj_frame_tiles(gObjectEventPic_CyndaquilDoll),
};

static const struct SpriteFrameImage sPicTable_ChikoritaDoll[] = {
    obj_frame_tiles(gObjectEventPic_ChikoritaDoll),
};

static const struct SpriteFrameImage sPicTable_TotodileDoll[] = {
    obj_frame_tiles(gObjectEventPic_TotodileDoll),
};

static const struct SpriteFrameImage sPicTable_JigglypuffDoll[] = {
    obj_frame_tiles(gObjectEventPic_JigglypuffDoll),
};

static const struct SpriteFrameImage sPicTable_MeowthDoll[] = {
    obj_frame_tiles(gObjectEventPic_MeowthDoll),
};

static const struct SpriteFrameImage sPicTable_ClefairyDoll[] = {
    obj_frame_tiles(gObjectEventPic_ClefairyDoll),
};

static const struct SpriteFrameImage sPicTable_DittoDoll[] = {
    obj_frame_tiles(gObjectEventPic_DittoDoll),
};

static const struct SpriteFrameImage sPicTable_SmoochumDoll[] = {
    obj_frame_tiles(gObjectEventPic_SmoochumDoll),
};

static const struct SpriteFrameImage sPicTable_TreeckoDoll[] = {
    obj_frame_tiles(gObjectEventPic_TreeckoDoll),
};

static const struct SpriteFrameImage sPicTable_TorchicDoll[] = {
    obj_frame_tiles(gObjectEventPic_TorchicDoll),
};

static const struct SpriteFrameImage sPicTable_MudkipDoll[] = {
    obj_frame_tiles(gObjectEventPic_MudkipDoll),
};

static const struct SpriteFrameImage sPicTable_DuskullDoll[] = {
    obj_frame_tiles(gObjectEventPic_DuskullDoll),
};

static const struct SpriteFrameImage sPicTable_WynautDoll[] = {
    obj_frame_tiles(gObjectEventPic_WynautDoll),
};

static const struct SpriteFrameImage sPicTable_BaltoyDoll[] = {
    obj_frame_tiles(gObjectEventPic_BaltoyDoll),
};

static const struct SpriteFrameImage sPicTable_KecleonDoll[] = {
    obj_frame_tiles(gObjectEventPic_KecleonDoll),
};

static const struct SpriteFrameImage sPicTable_AzurillDoll[] = {
    obj_frame_tiles(gObjectEventPic_AzurillDoll),
};

static const struct SpriteFrameImage sPicTable_SkittyDoll[] = {
    obj_frame_tiles(gObjectEventPic_SkittyDoll),
};

static const struct SpriteFrameImage sPicTable_SwabluDoll[] = {
    obj_frame_tiles(gObjectEventPic_SwabluDoll),
};

static const struct SpriteFrameImage sPicTable_GulpinDoll[] = {
    obj_frame_tiles(gObjectEventPic_GulpinDoll),
};

static const struct SpriteFrameImage sPicTable_LotadDoll[] = {
    obj_frame_tiles(gObjectEventPic_LotadDoll),
};

static const struct SpriteFrameImage sPicTable_SeedotDoll[] = {
    obj_frame_tiles(gObjectEventPic_SeedotDoll),
};

static const struct SpriteFrameImage sPicTable_PikaCushion[] = {
    obj_frame_tiles(gObjectEventPic_PikaCushion),
};

static const struct SpriteFrameImage sPicTable_RoundCushion[] = {
    obj_frame_tiles(gObjectEventPic_RoundCushion),
};

static const struct SpriteFrameImage sPicTable_KissCushion[] = {
    obj_frame_tiles(gObjectEventPic_KissCushion),
};

static const struct SpriteFrameImage sPicTable_ZigzagCushion[] = {
    obj_frame_tiles(gObjectEventPic_ZigzagCushion),
};

static const struct SpriteFrameImage sPicTable_SpinCushion[] = {
    obj_frame_tiles(gObjectEventPic_SpinCushion),
};

static const struct SpriteFrameImage sPicTable_DiamondCushion[] = {
    obj_frame_tiles(gObjectEventPic_DiamondCushion),
};

static const struct SpriteFrameImage sPicTable_BallCushion[] = {
    obj_frame_tiles(gObjectEventPic_BallCushion),
};

static const struct SpriteFrameImage sPicTable_GrassCushion[] = {
    obj_frame_tiles(gObjectEventPic_GrassCushion),
};

static const struct SpriteFrameImage sPicTable_FireCushion[] = {
    obj_frame_tiles(gObjectEventPic_FireCushion),
};

static const struct SpriteFrameImage sPicTable_WaterCushion[] = {
    obj_frame_tiles(gObjectEventPic_WaterCushion),
};

static const struct SpriteFrameImage sPicTable_BigSnorlaxDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigSnorlaxDoll),
};

static const struct SpriteFrameImage sPicTable_BigRhydonDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigRhydonDoll),
};

static const struct SpriteFrameImage sPicTable_BigLaprasDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigLaprasDoll),
};

static const struct SpriteFrameImage sPicTable_BigVenusaurDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigVenusaurDoll),
};

static const struct SpriteFrameImage sPicTable_BigCharizardDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigCharizardDoll),
};

static const struct SpriteFrameImage sPicTable_BigBlastoiseDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigBlastoiseDoll),
};

static const struct SpriteFrameImage sPicTable_BigWailmerDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigWailmerDoll),
};

static const struct SpriteFrameImage sPicTable_BigRegirockDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigRegirockDoll),
};

static const struct SpriteFrameImage sPicTable_BigRegiceDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigRegiceDoll),
};

static const struct SpriteFrameImage sPicTable_BigRegisteelDoll[] = {
    obj_frame_tiles(gObjectEventPic_BigRegisteelDoll),
};

static const struct SpriteFrameImage sPicTable_LatiasLatios[] = {
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 0),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 0),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 0),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 1),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 2),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 1),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 2),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 1),
    overworld_frame(gObjectEventPic_LatiasLatios, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_GameboyKid[] = {
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GameboyKid, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_ContestJudge[] = {
    overworld_ascending_frames(gObjectEventPic_ContestJudge, 2, 4),
};

static const struct SpriteFrameImage sPicTable_BrendanWatering[] = {
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 0),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 2),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 4),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 1),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 3),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 3),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 5),
    overworld_frame(gObjectEventPic_BrendanWatering, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_MayWatering[] = {
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 0),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 2),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 4),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 1),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 1),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 3),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 3),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 5),
    overworld_frame(gObjectEventPic_MayWatering, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_BrendanDecorating[] = {
    obj_frame_tiles(gObjectEventPic_BrendanDecorating),
};

static const struct SpriteFrameImage sPicTable_MayDecorating[] = {
    obj_frame_tiles(gObjectEventPic_MayDecorating),
};

static const struct SpriteFrameImage sPicTable_Archie[] = {
    overworld_ascending_frames(gObjectEventPic_Archie, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Maxie[] = {
    overworld_ascending_frames(gObjectEventPic_Maxie, 2, 4),
};

static const struct SpriteFrameImage sPicTable_KyogreFront[] = {
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_GroudonFront[] = {
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_KyogreSide[] = {
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_KyogreOld, 4, 4, 3),
};

static const struct SpriteFrameImage sPicTable_GroudonSide[] = {
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 2),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
    overworld_frame(gObjectEventPic_GroudonOld, 4, 4, 3),
};

static const struct SpriteFrameImage sPicTable_Fossil[] = {
    obj_frame_tiles(gObjectEventPic_Fossil),
};

static const struct SpriteFrameImage sPicTable_Regi[] = {
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
    obj_frame_tiles(gObjectEventPic_Regi),
};

static const struct SpriteFrameImage sPicTable_RayquazaStill[] = {
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
    obj_frame_tiles(gObjectEventPic_RayquazaStill),
};

static const struct SpriteFrameImage sPicTable_TuberMSwimming[] = {
    overworld_ascending_frames(gObjectEventPic_TuberMSwimming, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Mom[] = {
    overworld_ascending_frames(gObjectEventPic_Mom, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Scott[] = {
    overworld_ascending_frames(gObjectEventPic_Scott, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Juan[] = {
    overworld_ascending_frames(gObjectEventPic_Juan, 2, 4),
};

static const struct SpriteFrameImage sPicTable_MysteryEventDeliveryman[] = {
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Statue[] = {
    obj_frame_tiles(gObjectEventPic_Statue),
};

static const struct SpriteFrameImage sPicTable_UnionRoomAttendant[] = {
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomAttendant, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Red[] = {
    overworld_ascending_frames(gObjectEventPic_Red, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Leaf[] = {
    overworld_ascending_frames(gObjectEventPic_Leaf, 2, 4),
};

static const struct SpriteFrameImage sPicTable_SudowoodoTree[] = {
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 1),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 0),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 1),
    overworld_frame(gObjectEventPic_SudowoodoTree, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_RayquazaCutscene[] = {
    overworld_frame(gObjectEventPic_RayquazaCutscene, 8, 8, 0),
    overworld_frame(gObjectEventPic_RayquazaCutscene, 8, 8, 1),
    overworld_frame(gObjectEventPic_RayquazaCutscene, 8, 8, 2),
    overworld_frame(gObjectEventPic_RayquazaCutscene, 8, 8, 3),
    overworld_frame(gObjectEventPic_RayquazaCutscene, 8, 8, 4),
};

static const struct SpriteFrameImage sPicTable_BirthIslandStone[] = {
    obj_frame_tiles(gObjectEventPic_BirthIslandStone),
};

static const struct SpriteFrameImage sPicTable_Anabel[] = {
    overworld_ascending_frames(gObjectEventPic_Anabel, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Tucker[] = {
    overworld_ascending_frames(gObjectEventPic_Tucker, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Spenser[] = {
    overworld_ascending_frames(gObjectEventPic_Spenser, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Greta[] = {
    overworld_ascending_frames(gObjectEventPic_Greta, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Noland[] = {
    overworld_ascending_frames(gObjectEventPic_Noland, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Lucy[] = {
    overworld_ascending_frames(gObjectEventPic_Lucy, 2, 4),
};

static const struct SpriteFrameImage sPicTable_Brandon[] = {
    overworld_ascending_frames(gObjectEventPic_Brandon, 2, 4),
};

static const struct SpriteFrameImage sPicTable_PokeBall[] = {
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 0),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 1),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 2),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 3),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 4),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 0),
};

extern const struct SpriteFrameImage gFieldEffectObjectPicTable_BallLight[];
#if IS_HNS
extern const struct SpriteFrameImage gFieldEffectObjectPicTable_BallLight_Hns[];
extern const struct SpriteFrameImage gFieldEffectObjectPicTable_SmallLight_Hns[];
extern const struct SpriteFrameImage gFieldEffectObjectPicTable_PokeCenterLight_Hns[];
extern const struct SpriteFrameImage gFieldEffectObjectPicTable_MartLight_Hns[];
#endif

#if OW_FOLLOWERS_POKEBALLS
#define POKEBALL_PIC_FRAMES(name)                              \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 0),    \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 1),    \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 2),    \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 3),    \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 4),    \
    overworld_frame(gObjectEventPic_##name##Ball, 2, 4, 0)

static const struct SpriteFrameImage sPicTable_Ball_MASTER[] = {
    POKEBALL_PIC_FRAMES(Master),
};
static const struct SpriteFrameImage sPicTable_Ball_ULTRA[] = {
    POKEBALL_PIC_FRAMES(Ultra),
};
static const struct SpriteFrameImage sPicTable_Ball_GREAT[] = {
    POKEBALL_PIC_FRAMES(Great),
};
static const struct SpriteFrameImage sPicTable_Ball_SAFARI[] = {
    POKEBALL_PIC_FRAMES(Safari),
};
static const struct SpriteFrameImage sPicTable_Ball_NET[] = {
    POKEBALL_PIC_FRAMES(Net),
};
static const struct SpriteFrameImage sPicTable_Ball_DIVE[] = {
    POKEBALL_PIC_FRAMES(Dive),
};
static const struct SpriteFrameImage sPicTable_Ball_NEST[] = {
    POKEBALL_PIC_FRAMES(Nest),
};
static const struct SpriteFrameImage sPicTable_Ball_REPEAT[] = {
    POKEBALL_PIC_FRAMES(Repeat),
};
static const struct SpriteFrameImage sPicTable_Ball_TIMER[] = {
    POKEBALL_PIC_FRAMES(Timer),
};
static const struct SpriteFrameImage sPicTable_Ball_LUXURY[] = {
    POKEBALL_PIC_FRAMES(Luxury),
};
static const struct SpriteFrameImage sPicTable_Ball_PREMIER[] = {
    POKEBALL_PIC_FRAMES(Premier),
};
static const struct SpriteFrameImage sPicTable_Ball_DUSK[] = {
    POKEBALL_PIC_FRAMES(Dusk),
};
static const struct SpriteFrameImage sPicTable_Ball_HEAL[] = {
    POKEBALL_PIC_FRAMES(Heal),
};
static const struct SpriteFrameImage sPicTable_Ball_QUICK[] = {
    POKEBALL_PIC_FRAMES(Quick),
};
static const struct SpriteFrameImage sPicTable_Ball_CHERISH[] = {
    POKEBALL_PIC_FRAMES(Cherish),
};
static const struct SpriteFrameImage sPicTable_Ball_PARK[] = {
    POKEBALL_PIC_FRAMES(Park),
};
static const struct SpriteFrameImage sPicTable_Ball_FAST[] = {
    POKEBALL_PIC_FRAMES(Fast),
};
static const struct SpriteFrameImage sPicTable_Ball_LEVEL[] = {
    POKEBALL_PIC_FRAMES(Level),
};
static const struct SpriteFrameImage sPicTable_Ball_LURE[] = {
    POKEBALL_PIC_FRAMES(Lure),
};
static const struct SpriteFrameImage sPicTable_Ball_HEAVY[] = {
    POKEBALL_PIC_FRAMES(Heavy),
};
static const struct SpriteFrameImage sPicTable_Ball_LOVE[] = {
    POKEBALL_PIC_FRAMES(Love),
};
static const struct SpriteFrameImage sPicTable_Ball_FRIEND[] = {
    POKEBALL_PIC_FRAMES(Friend),
};
static const struct SpriteFrameImage sPicTable_Ball_MOON[] = {
    POKEBALL_PIC_FRAMES(Moon),
};
static const struct SpriteFrameImage sPicTable_Ball_SPORT[] = {
    POKEBALL_PIC_FRAMES(Sport),
};
static const struct SpriteFrameImage sPicTable_Ball_DREAM[] = {
    POKEBALL_PIC_FRAMES(Dream),
};
static const struct SpriteFrameImage sPicTable_Ball_BEAST[] = {
    POKEBALL_PIC_FRAMES(Beast),
};
#ifdef ITEM_STRANGE_BALL
static const struct SpriteFrameImage sPicTable_Ball_STRANGE[] = {
    POKEBALL_PIC_FRAMES(Strange),
};
#endif //ITEM_STRANGE_BALL
#endif //OW_FOLLOWERS_POKEBALLS

static const struct SpriteFrameImage sPicTable_DeoxysOld[] = {
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysOld, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_MewOld[] = {
    overworld_ascending_frames(gObjectEventPic_MewOld, 2, 4),
};

static const struct SpriteFrameImage sPicTable_DusclopsOld[] = {
    overworld_ascending_frames(gObjectEventPic_DusclopsOld, 2, 4),
};

static const struct SpriteFrameImage sPicTable_AzurillOld[] = {
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_AzurillOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_KecleonOld[] = {
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KecleonOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_WingullOld[] = {
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 4),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 3),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 3),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 5),
    overworld_frame(gObjectEventPic_WingullOld, 2, 2, 5),
};

static const struct SpriteFrameImage sPicTable_AzumarillOld[] = {
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_AzumarillOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_PikachuOld[] = {
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PikachuOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_ZigzagoonOld[] = {
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ZigzagoonOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_SkittyOld[] = {
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SkittyOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_PoochyenaOld[] = {
    overworld_ascending_frames(gObjectEventPic_PoochyenaOld, 4, 4),
};

static const struct SpriteFrameImage sPicTable_LugiaOld[] = {
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_LugiaOld, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_HoOhOld[] = {
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOhOld, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_RubySapphireBrendan[] = {
    overworld_ascending_frames(gObjectEventPic_RubySapphireBrendanNormal, 2, 4),
};

static const struct SpriteFrameImage sPicTable_KirliaOld[] = {
    overworld_ascending_frames(gObjectEventPic_KirliaOld, 2, 4),
};

static const struct SpriteFrameImage sPicTable_RubySapphireMay[] = {
    overworld_ascending_frames(gObjectEventPic_RubySapphireMayNormal, 2, 4),
};

static const struct SpriteFrameImage sPicTable_ApricornTree[] = {
    overworld_frame(gObjectEventPic_ApricornTree, 2, 2, 0),
};

#if IS_FRLG

static const struct SpriteFrameImage sPicTable_RedNormal[] = {
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 8),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 9),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 10),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 11),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 12),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 13),
};

static const struct SpriteFrameImage sPicTable_RedBike[] = {
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 5),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 6),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 7),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GreenNormal[] = {
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 8),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 9),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 10),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 11),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 12),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 13),
};

static const struct SpriteFrameImage sPicTable_GreenBike[] = {
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 5),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 6),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 7),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedSurf[] = {
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_GreenSurf[] = {
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_RedItem[] = {
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GreenItem[] = {
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedFish[] = {
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 5),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 6),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 7),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 8),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 9),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 10),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 11),
};

static const struct SpriteFrameImage sPicTable_GreenFish[] = {
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 5),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 6),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 7),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 8),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 9),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 10),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 11),
};

static const struct SpriteFrameImage sPicTable_RedVSSeekerBike[] = {
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_GreenVSSeekerBike[] = {
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_Policeman[] = {
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 0),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 1),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 2),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 3),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 4),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 5),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 6),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 7),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_LittleBoyFrlg[] = {
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 3),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 4),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 5),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 6),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 7),
    overworld_frame(gObjectEventPic_LittleBoyFrlg, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_LittleGirlFrlg[] = {
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 3),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 4),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 5),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 6),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 7),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 8),
    overworld_frame(gObjectEventPic_LittleGirlFrlg, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_SittingBoy[] = {
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
};

static const struct SpriteFrameImage sPicTable_LassFrlg[] = {
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_LassFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_YoungsterFrlg[] = {
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_YoungsterFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman1Frlg[] = {
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_Woman1Frlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman3Frlg[] = {
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman3Frlg, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BattleGirl[] = {
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 0),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 1),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 2),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 3),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 4),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 5),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 6),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 7),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 8),
    overworld_frame(gObjectEventPic_BattleGirl, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_BugCatcherFrlg[] = {
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_BugCatcherFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_FatManFrlg[] = {
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_FatManFrlg, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BaldingMan[] = {
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 2),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 3),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 4),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 5),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 6),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 7),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 8),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman2Frlg[] = {
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_Woman2Frlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_OldMan1[] = {
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 8),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_WorkerM[] = {
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_WorkerF[] = {
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BeautyFrlg[] = {
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_BeautyFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Chef[] = {
    overworld_frame(gObjectEventPic_Chef, 2, 4, 0),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 1),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 2),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 3),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 4),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 5),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 6),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 7),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_OldMan2[] = {
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_OldManLyingDown[] = {
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_OldWomanFrlg[] = {
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldWomanFrlg, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_CamperFrlg[] = {
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_CamperFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_PicnickerFrlg[] = {
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_PicnickerFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_CooltrainerM[] = {
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 8),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_CooltrainerF[] = {
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 8),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Boy[] = {
    overworld_frame(gObjectEventPic_Boy, 2, 4, 0),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 1),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 2),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 3),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 4),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 5),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 6),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 7),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 8),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SuperNerd[] = {
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 0),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 1),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 2),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 3),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 4),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 5),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 6),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 7),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 8),
    overworld_frame(gObjectEventPic_SuperNerd, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Channeler[] = {
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 0),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 1),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 2),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 3),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 4),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 5),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 6),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 7),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 8),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_RocketF[] = {
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SwimmerMWater[] = {
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerFWater[] = {
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerMLand[] = {
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerFLand[] = {
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Blackbelt[] = {
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 3),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 4),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 5),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 6),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 7),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 8),
    overworld_frame(gObjectEventPic_Blackbelt, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Scientist[] = {
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 0),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 1),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 2),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 3),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 4),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 5),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 6),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 7),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 8),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_GentlemanFrlg[] = {
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_GentlemanFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SailorFrlg[] = {
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_SailorFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Captain[] = {
    overworld_frame(gObjectEventPic_Captain, 2, 4, 0),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 1),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 2),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 3),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 4),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 5),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 6),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 7),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Fisher[] = {
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 0),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 1),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 2),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 3),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 4),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 5),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 6),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 7),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 8),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_TeachyTVHost[] = {
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 0),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 1),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 2),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 3),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 4),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 5),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 6),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 7),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_TuberFFrlg[] = {
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberFFrlg, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_TuberMWater[] = {
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_TuberMLand[] = {
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_HikerFrlg[] = {
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 3),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 4),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 5),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 6),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 7),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 8),
    overworld_frame(gObjectEventPic_HikerFrlg, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Biker[] = {
    overworld_frame(gObjectEventPic_Biker, 4, 4, 0),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 1),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 2),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 3),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 4),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 5),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 6),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 7),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 8),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 9),
};

static const struct SpriteFrameImage sPicTable_GymGuy[] = {
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 0),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 1),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 2),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 3),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 4),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 5),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 6),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 7),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_NurseFrlg[] = {
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_NurseFrlg, 2, 4, 3),
};

static const struct SpriteFrameImage sPicTable_ProfOak[] = {
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 0),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 1),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 2),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 3),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 4),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 5),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 6),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 7),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Man[] = {
    overworld_frame(gObjectEventPic_Man, 2, 4, 0),
    overworld_frame(gObjectEventPic_Man, 2, 4, 1),
    overworld_frame(gObjectEventPic_Man, 2, 4, 2),
    overworld_frame(gObjectEventPic_Man, 2, 4, 3),
    overworld_frame(gObjectEventPic_Man, 2, 4, 4),
    overworld_frame(gObjectEventPic_Man, 2, 4, 5),
    overworld_frame(gObjectEventPic_Man, 2, 4, 6),
    overworld_frame(gObjectEventPic_Man, 2, 4, 7),
    overworld_frame(gObjectEventPic_Man, 2, 4, 8),
    overworld_frame(gObjectEventPic_Man, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Rocker[] = {
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 0),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 1),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 2),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 3),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 4),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 5),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 6),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 7),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 8),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_MrFuji[] = {
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 0),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 1),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 2),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 3),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 4),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 5),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 6),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 7),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Bruno[] = {
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_CuttableTreeFrlg[] = {
    overworld_frame(gObjectEventPic_CuttableTreeFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_CuttableTreeFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_CuttableTreeFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_CuttableTreeFrlg, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_Clerk[] = {
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 0),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 1),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 2),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 3),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 4),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 5),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 6),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 7),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_MGDeliveryman[] = {
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_TrainerTowerDude[] = {
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_CableClubReceptionist[] = {
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_UnionRoomReceptionist[] = {
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_BreakableRockFrlg[] = {
    overworld_frame(gObjectEventPic_BreakableRockFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_BreakableRockFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_BreakableRockFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_BreakableRockFrlg, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_PushableBoulderFrlg[] = {
    overworld_frame(gObjectEventPic_PushableBoulderFrlg, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_RocketM[] = {
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Celio[] = {
    overworld_frame(gObjectEventPic_Celio, 2, 4, 0),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 1),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 2),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 3),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 4),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 5),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 6),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 7),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Agatha[] = {
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Brock[] = {
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Misty[] = {
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_LtSurge[] = {
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Erika[] = {
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Koga[] = {
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Giovanni[] = {
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 0),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 1),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 2),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 3),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 4),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 5),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 6),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 7),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Blaine[] = {
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Sabrina[] = {
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Bill[] = {
    overworld_frame(gObjectEventPic_Bill, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 3),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 4),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 5),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 6),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 7),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Daisy[] = {
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 0),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 1),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 2),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 3),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 4),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 5),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 6),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 7),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lorelei[] = {
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lance[] = {
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Blue[] = {
    overworld_frame(gObjectEventPic_Blue, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 3),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 4),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 5),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 6),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 7),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_TownMap[] = {
    overworld_frame(gObjectEventPic_TownMap, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Pokedex[] = {
    overworld_frame(gObjectEventPic_Pokedex, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_GBAKid[] = {
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_FossilFrlg[] = {
    overworld_frame(gObjectEventPic_FossilFrlg, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Ruby[] = {
    overworld_frame(gObjectEventPic_Ruby, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Sapphire[] = {
    overworld_frame(gObjectEventPic_Sapphire, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_OldAmber[] = {
    overworld_frame(gObjectEventPic_OldAmber, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_GymSign[] = {
    overworld_frame(gObjectEventPic_GymSign, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Sign[] = {
    overworld_frame(gObjectEventPic_Sign, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_WoodenSign[] = {
    overworld_frame(gObjectEventPic_WoodenSign, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Clipboard[] = {
    overworld_frame(gObjectEventPic_Clipboard, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_BirthIslandStoneFrlg[] = {
    overworld_frame(gObjectEventPic_BirthIslandStoneFrlg, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_LaprasDoll[] = {
    overworld_frame(gObjectEventPic_LaprasDoll, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Seagallop[] = {
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
};

static const struct SpriteFrameImage sPicTable_SSAnne[] = {
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
};

static const struct SpriteFrameImage sPicTable_Snorlax[] = {
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_SnorlaxOld, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Spearow[] = {
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SpearowOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Pidgeot[] = {
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PidgeotOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Omanyte[] = {
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_OmanyteOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Kangaskhan[] = {
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KangaskhanOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Psyduck[] = {
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PsyduckOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_NidoranF[] = {
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranFOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_NidoranM[] = {
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranMOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Nidorino[] = {
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidorinoOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Meowth[] = {
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MeowthOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Seel[] = {
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SeelOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Voltorb[] = {
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_VoltorbOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Slowpoke[] = {
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SlowpokeOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Slowbro[] = {
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_SlowbroOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Machop[] = {
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MachopOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Wigglytuff[] = {
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_WigglytuffOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Doduo[] = {
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_DoduoOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Fearow[] = {
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_FearowOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Lapras[] = {
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_LaprasOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Zapdos[] = {
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ZapdosOld, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Moltres[] = {
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_MoltresOld, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Articuno[] = {
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
    overworld_frame(gObjectEventPic_ArticunoOld, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_DeoxysD[] = {
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_DeoxysA[] = {
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_DeoxysN[] = {
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_Mewtwo[] = {
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MewtwoOld, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Entei[] = {
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_EnteiOld, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Raikou[] = {
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_RaikouOld, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Suicune[] = {
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_SuicuneOld, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Celebi[] = {
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CelebiOld, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Cubone[] = {
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_CuboneOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Poliwrath[] = {
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PoliwrathOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Chansey[] = {
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ChanseyOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_PikachuFrlg[] = {
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 0),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 1),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 2),
    overworld_frame(gObjectEventPic_PikachuOldFrlg, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Jigglypuff[] = {
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_JigglypuffOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Pidgey[] = {
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_PidgeyOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Clefairy[] = {
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_ClefairyOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Machoke[] = {
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_MachokeOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Kabuto[] = {
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 0),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 1),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 2),
    overworld_frame(gObjectEventPic_KabutoOld, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_MomFrlg[] = {
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 0),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 1),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 2),
    overworld_frame(gObjectEventPic_MomFrlg, 2, 4, 2),
};

#endif // IS_FRLG

#if IS_HNS
static const struct SpriteFrameImage sPicTable_AttendantF_hns[] = {
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_AttendantF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_AttendantM_hns[] = {
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_AttendantM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BaldingMan_hns[] = {
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_BaldingMan_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BattleGirl_hns[] = {
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_BattleGirl_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BattleTowerTrainerDude_hns[] = {
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_BattleTowerTrainerDude_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Beauty_hns[] = {
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Beauty_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Biker_hns[] = {
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 5),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 6),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 7),
    overworld_frame(gObjectEventPic_Biker_hns, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BlackBelt_hns[] = {
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_BlackBelt_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Boy2_hns[] = {
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Boy2_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BugCatcher_hns[] = {
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_BugCatcher_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Burglar_hns[] = {
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Burglar_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Camper_hns[] = {
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Camper_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Captain_hns[] = {
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Captain_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Channeler_hns[] = {
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Channeler_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Cook_hns[] = {
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Cook_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_CooltrainerF_hns[] = {
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_CooltrainerM_hns[] = {
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Man_hns[] = {
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Man_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Engineer_hns[] = {
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Engineer_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_FatMan_hns[] = {
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_FatMan_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Firebreather_hns[] = {
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Firebreather_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Fisherman_hns[] = {
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Fisherman_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GameboyKid_hns[] = {
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_GameboyKid_hns, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Gentleman_hns[] = {
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Gentleman_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Girl1_hns[] = {
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Girl1_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GymGuy_hns[] = {
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_GymGuy_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Hiker_hns[] = {
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Hiker_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Juggler_hns[] = {
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Juggler_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lass_hns[] = {
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lass_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_LinkReceptionist_hns[] = {
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_LinkReceptionist_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_LittleBoy_hns[] = { overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 0), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 1), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 2), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 3), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 4), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 5), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 6), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 7), overworld_frame(gObjectEventPic_LittleBoy_hns, 2, 4, 8), };

static const struct SpriteFrameImage sPicTable_LittleGirl_hns[] = {
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 3),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 4),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 5),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 6),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 7),
    overworld_frame(gObjectEventPic_LittleGirl_hns, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_MartEmployee_hns[] = {
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_MartEmployee_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Mom_hns[] = {
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Mom_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_MysteryEventDeliveryman_hns[] = {
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_MysteryEventDeliveryman_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Nurse_hns[] = {
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse_hns, 2, 4, 3),
};

static const struct SpriteFrameImage sPicTable_Officer_hns[] = {
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Officer_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_OldMan_hns[] = {
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldMan_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_OldMan2_hns[] = {
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldMan2_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_OldWoman_hns[] = {
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldWoman_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Picnicker_hns[] = {
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Picnicker_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_PsychicM_hns[] = {
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_PsychicM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Rocker_hns[] = {
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Rocker_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Sage_hns[] = {
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Sage_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SageElder_hns[] = {
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_SageElder_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Sailor_hns[] = {
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Sailor_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_ScientistF_hns[] = {
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_ScientistF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_ScientistM_hns[] = {
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_ScientistM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SkierF_hns[] = {
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 5),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 6),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 7),
    overworld_frame(gObjectEventPic_SkierF_hns, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SkierM_hns[] = {
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 5),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 6),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 7),
    overworld_frame(gObjectEventPic_SkierM_hns, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SuperNerd_hns[] = {
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_SuperNerd_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SwimmerF_hns[] = {
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SwimmerFLand_hns[] = {
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerFLand_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_SwimmerM_hns[] = {
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_TuberF_hns[] = {
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberF_hns, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_TuberM_hns[] = {
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberM_hns, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_TuberMSwimming_hns[] = {
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberMSwimming_hns, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_Twin_hns[] = {
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Twin_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Woman1_hns[] = {
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman1_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Woman2_hns[] = {
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman2_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Woman3_hns[] = {
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman3_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_WorkerF_hns[] = {
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_WorkerM_hns[] = {
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Youngster_hns[] = {
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Youngster_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Bruno_hns[] = {
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Bruno_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Karen_hns[] = {
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Karen_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Koga_hns[] = {
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Koga_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lance_hns[] = {
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lance_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Will_hns[] = {
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Will_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Anabel_hns[] = {
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Anabel_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Brandon_hns[] = {
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Brandon_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Greta_hns[] = {
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Greta_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lucy_hns[] = {
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lucy_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Noland_hns[] = {
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Noland_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Spenser_hns[] = {
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Spenser_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Tucker_hns[] = {
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Tucker_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Blaine_hns[] = {
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Blaine_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Blue_hns[] = {
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Blue_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Brock_hns[] = {
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Brock_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Bugsy_hns[] = {
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Bugsy_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Chuck_hns[] = {
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Chuck_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Clair_hns[] = {
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Clair_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Erika_hns[] = {
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Erika_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Falkner_hns[] = {
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Falkner_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Janine_hns[] = {
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Janine_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Jasmine_hns[] = {
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Jasmine_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Misty_hns[] = {
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Misty_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Morty_hns[] = {
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Morty_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Pryce_hns[] = {
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Pryce_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Sabrina_hns[] = {
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Sabrina_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Surge_hns[] = {
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Surge_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Whitney_hns[] = {
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Whitney_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Archer_hns[] = {
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Archer_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Ariana_hns[] = {
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Ariana_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Giovanni_hns[] = {
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Giovanni_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Petrel_hns[] = {
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Petrel_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Proton_hns[] = {
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Proton_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RocketF_hns[] = {
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketF_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RocketM_hns[] = {
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketM_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Bill_hns[] = {
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Bill_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Elm_hns[] = {
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Elm_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Eusine_hns[] = {
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Eusine_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Kimono_hns[] = {
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Kimono_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Kurt_hns[] = {
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Kurt_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_KurtLyingDown_hns[] = {
    obj_frame_tiles(gObjectEventPic_KurtLyingDown_hns),
};

static const struct SpriteFrameImage sPicTable_ProfOak_hns[] = {
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_ProfOak_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedNormal_hns[] = {
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedNormal_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Scott_hns[] = {
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Scott_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Silver_hns[] = {
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Silver_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Steven_hns[] = {
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_Steven_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_AlolaOak_hns[] = {
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_AlolaOak_hns, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BirthIslandStone_hns[] = {
    obj_frame_tiles(gObjectEventPic_BirthIslandStone_hns),
};

static const struct SpriteFrameImage sPicTable_BreakableRock_hns[] = {
    overworld_frame(gObjectEventPic_BreakableRock_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_BreakableRock_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_BreakableRock_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_BreakableRock_hns, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_CuttableTree_hns[] = {
    overworld_frame(gObjectEventPic_CuttableTree_hns, 2, 2, 0),
    overworld_frame(gObjectEventPic_CuttableTree_hns, 2, 2, 1),
    overworld_frame(gObjectEventPic_CuttableTree_hns, 2, 2, 2),
    overworld_frame(gObjectEventPic_CuttableTree_hns, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_Fossil_hns[] = {
    obj_frame_tiles(gObjectEventPic_Fossil_hns),
};

static const struct SpriteFrameImage sPicTable_ItemBall_hns[] = {
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 0),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 1),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 2),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 3),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 4),
    overworld_frame(gObjectEventPic_PokeBall, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_LegendaryShadow_hns[] = {
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
    obj_frame_tiles(gObjectEventPic_LegendaryShadow_hns),
};

static const struct SpriteFrameImage sPicTable_NoTailSlowpoke_hns[] = {
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_NoTailSlowpoke_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_PushableBoulder_hns[] = {
    obj_frame_tiles(gObjectEventPic_PushableBoulder_hns),
};

static const struct SpriteFrameImage sPicTable_ShinyGyarados_hns[] = {
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_ShinyGyarados_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_SleepingSnorlax_hns[] = {
    obj_frame_tiles(gObjectEventPic_SleepingSnorlax_hns),
};

static const struct SpriteFrameImage sPicTable_SsAqua_hns[] = {
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
    obj_frame_tiles(gObjectEventPic_SsAqua_hns),
};

static const struct SpriteFrameImage sPicTable_SwimmingLapras_hns[] = {
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_SwimmingLapras_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_TowerBeam_hns[] = {
    overworld_frame(gObjectEventPic_TowerBeam_hns, 8, 8, 0),
    overworld_frame(gObjectEventPic_TowerBeam_hns, 8, 8, 1),
    overworld_frame(gObjectEventPic_TowerBeam_hns, 8, 8, 2),
    overworld_frame(gObjectEventPic_TowerBeam_hns, 8, 8, 3),
    overworld_frame(gObjectEventPic_TowerBeam_hns, 8, 8, 4),
};

static const struct SpriteFrameImage sPicTable_TrainEast_hns[] = {
    obj_frame_tiles(gObjectEventPic_TrainEast_hns),
};

static const struct SpriteFrameImage sPicTable_TrainWest_hns[] = {
    obj_frame_tiles(gObjectEventPic_TrainWest_hns),
};

static const struct SpriteFrameImage sPicTable_Whirlpool_hns[] = {
    overworld_frame(gObjectEventPic_Whirlpool_hns, 8, 8, 0),
    overworld_frame(gObjectEventPic_Whirlpool_hns, 8, 8, 1),
    overworld_frame(gObjectEventPic_Whirlpool_hns, 8, 8, 2),
    overworld_frame(gObjectEventPic_Whirlpool_hns, 8, 8, 3),
    overworld_frame(gObjectEventPic_Whirlpool_hns, 8, 8, 4),
};

static const struct SpriteFrameImage sPicTable_NurseChansey_hns[] = {
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 0),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 1),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 2),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 3),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 4),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 5),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 6),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 7),
    overworld_frame(gObjectEventPic_NurseChansey_hns, 2, 4, 8),
};

// HnS protagonist pic tables
static const struct SpriteFrameImage sPicTable_GoldNormal_hns[] = {
    overworld_ascending_frames(gObjectEventPic_GoldNormalRunning_hns, 2, 4),
};

static const struct SpriteFrameImage sPicTable_GoldMachBike_hns[] = {
    overworld_ascending_frames(gObjectEventPic_GoldMachBike_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_GoldAcroBike_hns[] = {
    overworld_ascending_frames(gObjectEventPic_GoldAcroBike_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_GoldSurfing_hns[] = {
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_GoldSurfing_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_GoldUnderwater_hns[] = {
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldUnderwater_hns, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_GoldFieldMove_hns[] = {
    overworld_ascending_frames(gObjectEventPic_GoldFieldMove_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_GoldFishing_hns[] = {
    overworld_ascending_frames(gObjectEventPic_GoldFishing_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_GoldWatering_hns[] = {
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 5),
    overworld_frame(gObjectEventPic_GoldWatering_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_GoldDecorating_hns[] = {
    obj_frame_tiles(gObjectEventPic_GoldDecorating_hns),
};

static const struct SpriteFrameImage sPicTable_KrisNormal_hns[] = {
    overworld_ascending_frames(gObjectEventPic_KrisNormalRunning_hns, 2, 4),
};

static const struct SpriteFrameImage sPicTable_KrisMachBike_hns[] = {
    overworld_ascending_frames(gObjectEventPic_KrisMachBike_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_KrisAcroBike_hns[] = {
    overworld_ascending_frames(gObjectEventPic_KrisAcroBike_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_KrisSurfing_hns[] = {
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_KrisSurfing_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_KrisUnderwater_hns[] = {
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisUnderwater_hns, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_KrisFieldMove_hns[] = {
    overworld_ascending_frames(gObjectEventPic_KrisFieldMove_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_KrisFishing_hns[] = {
    overworld_ascending_frames(gObjectEventPic_KrisFishing_hns, 4, 4),
};

static const struct SpriteFrameImage sPicTable_KrisWatering_hns[] = {
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 0),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 2),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 4),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 1),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 3),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 5),
    overworld_frame(gObjectEventPic_KrisWatering_hns, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_KrisDecorating_hns[] = {
    obj_frame_tiles(gObjectEventPic_KrisDecorating_hns),
};

#endif // IS_HNS

