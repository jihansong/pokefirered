
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int32_t s32;
typedef uint8_t bool8;
#define TRUE 1
#define FALSE 0
#define max(a,b) ((a) > (b) ? (a) : (b))
#define MAX_MON_MOVES 4
#define PLAYER_NAME_LENGTH 7
#define POKEMON_NAME_LENGTH 10
#define PARTY_SIZE 6
#define IN_BOX_COUNT 30
#define TOTAL_BOXES_COUNT 14
#define MOVES_COUNT 355
#define MOVE_NONE 0
#define SPECIES_NONE 0
#define SPECIES_PIKACHU 25
#define EOS 255
#define VAR_PC_BOX_TO_SEND_MON 1
#define FLAG_SHOWN_BOX_WAS_FULL_MESSAGE 1
#define MON_GIVEN_TO_PARTY 0
#define MON_GIVEN_TO_PC 1
#define MON_CANT_GIVE 2
#define ARRAY_COUNT(a) (sizeof(a) / sizeof((a)[0]))
#define MON_DATA_PERSONALITY               0
#define MON_DATA_OT_ID                     1
#define MON_DATA_NICKNAME                  2
#define MON_DATA_LANGUAGE                  3
#define MON_DATA_SANITY_IS_BAD_EGG         4
#define MON_DATA_SANITY_HAS_SPECIES        5
#define MON_DATA_SANITY_IS_EGG             6
#define MON_DATA_OT_NAME                   7
#define MON_DATA_MARKINGS                  8
#define MON_DATA_CHECKSUM                  9
#define MON_DATA_ENCRYPT_SEPARATOR        10
#define MON_DATA_SPECIES                  11
#define MON_DATA_HELD_ITEM                12
#define MON_DATA_MOVE1                    13
#define MON_DATA_MOVE2                    14
#define MON_DATA_MOVE3                    15
#define MON_DATA_MOVE4                    16
#define MON_DATA_PP1                      17
#define MON_DATA_PP2                      18
#define MON_DATA_PP3                      19
#define MON_DATA_PP4                      20
#define MON_DATA_PP_BONUSES               21
#define MON_DATA_COOL                     22
#define MON_DATA_BEAUTY                   23
#define MON_DATA_CUTE                     24
#define MON_DATA_EXP                      25
#define MON_DATA_HP_EV                    26
#define MON_DATA_ATK_EV                   27
#define MON_DATA_DEF_EV                   28
#define MON_DATA_SPEED_EV                 29
#define MON_DATA_SPATK_EV                 30
#define MON_DATA_SPDEF_EV                 31
#define MON_DATA_FRIENDSHIP               32
#define MON_DATA_SMART                    33
#define MON_DATA_POKERUS                  34
#define MON_DATA_MET_LOCATION             35
#define MON_DATA_MET_LEVEL                36
#define MON_DATA_MET_GAME                 37
#define MON_DATA_POKEBALL                 38
#define MON_DATA_HP_IV                    39
#define MON_DATA_ATK_IV                   40
#define MON_DATA_DEF_IV                   41
#define MON_DATA_SPEED_IV                 42
#define MON_DATA_SPATK_IV                 43
#define MON_DATA_SPDEF_IV                 44
#define MON_DATA_IS_EGG                   45
#define MON_DATA_ABILITY_NUM              46
#define MON_DATA_TOUGH                    47
#define MON_DATA_SHEEN                    48
#define MON_DATA_OT_GENDER                49
#define MON_DATA_COOL_RIBBON              50
#define MON_DATA_BEAUTY_RIBBON            51
#define MON_DATA_CUTE_RIBBON              52
#define MON_DATA_SMART_RIBBON             53
#define MON_DATA_TOUGH_RIBBON             54
#define MON_DATA_STATUS                   55
#define MON_DATA_LEVEL                    56
#define MON_DATA_HP                       57
#define MON_DATA_MAX_HP                   58
#define MON_DATA_ATK                      59
#define MON_DATA_DEF                      60
#define MON_DATA_SPEED                    61
#define MON_DATA_SPATK                    62
#define MON_DATA_SPDEF                    63
#define MON_DATA_MAIL                     64
#define MON_DATA_SPECIES_OR_EGG           65
#define MON_DATA_IVS                      66
#define MON_DATA_CHAMPION_RIBBON          67
#define MON_DATA_WINNING_RIBBON           68
#define MON_DATA_VICTORY_RIBBON           69
#define MON_DATA_ARTIST_RIBBON            70
#define MON_DATA_EFFORT_RIBBON            71
#define MON_DATA_MARINE_RIBBON            72
#define MON_DATA_LAND_RIBBON              73
#define MON_DATA_SKY_RIBBON               74
#define MON_DATA_COUNTRY_RIBBON           75
#define MON_DATA_NATIONAL_RIBBON          76
#define MON_DATA_EARTH_RIBBON             77
#define MON_DATA_WORLD_RIBBON             78
#define MON_DATA_UNUSED_RIBBONS           79
#define MON_DATA_MODERN_FATEFUL_ENCOUNTER 80
#define MON_DATA_KNOWN_MOVES              81
#define MON_DATA_RIBBON_COUNT             82
#define MON_DATA_RIBBONS                  83
#define MON_DATA_ATK2                     84
#define MON_DATA_DEF2                     85
#define MON_DATA_SPEED2                   86
#define MON_DATA_SPATK2                   87
#define MON_DATA_SPDEF2                   88
#define MON_DATA_STARTER_PIKACHU          89 // BoxPokemon.isStarterPikachu
#define MON_DATA_SNAGGED                  90 // BoxPokemon.isSnagged
struct PokemonSubstruct0
{
    u16 species;
    u16 heldItem;
    u32 experience;
    u8 ppBonuses;
    u8 friendship;
    u16 filler;
};

struct PokemonSubstruct1
{
    u16 moves[MAX_MON_MOVES];
    u8 pp[MAX_MON_MOVES];
};

struct PokemonSubstruct2
{
    u8 hpEV;
    u8 attackEV;
    u8 defenseEV;
    u8 speedEV;
    u8 spAttackEV;
    u8 spDefenseEV;
    u8 cool;
    u8 beauty;
    u8 cute;
    u8 smart;
    u8 tough;
    u8 sheen;
};

struct PokemonSubstruct3
{
 /* 0x00 */ u8 pokerus;
 /* 0x01 */ u8 metLocation;

 /* 0x02 */ u16 metLevel:7;
 /* 0x02 */ u16 metGame:4;
 /* 0x03 */ u16 pokeball:4;
 /* 0x03 */ u16 otGender:1;

 /* 0x04 */ u32 hpIV:5;
 /* 0x04 */ u32 attackIV:5;
 /* 0x05 */ u32 defenseIV:5;
 /* 0x05 */ u32 speedIV:5;
 /* 0x05 */ u32 spAttackIV:5;
 /* 0x06 */ u32 spDefenseIV:5;
 /* 0x07 */ u32 isEgg:1;
 /* 0x07 */ u32 abilityNum:1;

 /* 0x08 */ u32 coolRibbon:3;               // Stores the highest contest rank achieved in the Cool category.
 /* 0x08 */ u32 beautyRibbon:3;             // Stores the highest contest rank achieved in the Beauty category.
 /* 0x08 */ u32 cuteRibbon:3;               // Stores the highest contest rank achieved in the Cute category.
 /* 0x09 */ u32 smartRibbon:3;              // Stores the highest contest rank achieved in the Smart category.
 /* 0x09 */ u32 toughRibbon:3;              // Stores the highest contest rank achieved in the Tough category.
 /* 0x09 */ u32 championRibbon:1;           // Given when defeating the Champion. Because both RSE and FRLG use it, later generations don't specify from which region it comes from.
 /* 0x0A */ u32 winningRibbon:1;            // Given at the Battle Tower's Level 50 challenge by winning a set of seven battles that extends the current streak to 56 or more.
 /* 0x0A */ u32 victoryRibbon:1;            // Given at the Battle Tower's Level 100 challenge by winning a set of seven battles that extends the current streak to 56 or more.
 /* 0x0A */ u32 artistRibbon:1;             // Given at the Contest Hall by winning a Master Rank contest with at least 800 points, and agreeing to have the Pokémon's portrait placed in the museum after being offered.
 /* 0x0A */ u32 effortRibbon:1;             // Given at Slateport's market to Pokémon with maximum EVs.
 /* 0x0A */ u32 marineRibbon:1;             // Never distributed.
 /* 0x0A */ u32 landRibbon:1;               // Never distributed.
 /* 0x0A */ u32 skyRibbon:1;                // Never distributed.
 /* 0x0A */ u32 countryRibbon:1;            // Distributed during Pokémon Festa '04 and '05 to tournament winners.
 /* 0x0B */ u32 nationalRibbon:1;           // Given to purified Shadow Pokémon in Colosseum/XD.
 /* 0x0B */ u32 earthRibbon:1;              // Given to teams that have beaten Mt. Battle's 100-battle challenge in Colosseum/XD.
 /* 0x0B */ u32 worldRibbon:1;              // Distributed during Pokémon Festa '04 and '05 to tournament winners.
 /* 0x0B */ u32 unusedRibbons:4;            // Discarded in Gen 4.

 // The functionality of this bit changed in FRLG:
 // In RS, this bit does nothing, is never set, & is accidentally unset when hatching Eggs.
 // In FRLG & Emerald, this controls Mew & Deoxys obedience and whether they can be traded.
 // If set, a Pokémon is a fateful encounter in FRLG's summary screen if hatched & for all Pokémon in Gen 4+ summary screens.
 // Set for in-game event island legendaries, events distributed after a certain date, & Pokémon from XD: Gale of Darkness.
 // Not to be confused with METLOC_FATEFUL_ENCOUNTER.
 /* 0x0B */ u32 modernFatefulEncounter:1;
};

// Number of bytes in the largest Pokémon substruct.
// They are assumed to be the same size, and will be padded to
// the largest size by the union.
// By default they are all 12 bytes.
#define NUM_SUBSTRUCT_BYTES (max(sizeof(struct PokemonSubstruct0),     \
                             max(sizeof(struct PokemonSubstruct1),     \
                             max(sizeof(struct PokemonSubstruct2),     \
                                 sizeof(struct PokemonSubstruct3)))))

union PokemonSubstruct
{
    struct PokemonSubstruct0 type0;
    struct PokemonSubstruct1 type1;
    struct PokemonSubstruct2 type2;
    struct PokemonSubstruct3 type3;
    u16 raw[NUM_SUBSTRUCT_BYTES / 2]; // /2 because it's u16, not u8
};

struct BoxPokemon
{
    u32 personality;
    u32 otId;
    u8 nickname[POKEMON_NAME_LENGTH];
    u8 language;
    u8 isBadEgg:1;
    u8 hasSpecies:1;
    u8 isEgg:1;
    u8 blockBoxRS:1; // Unused, but Pokémon Box Ruby & Sapphire will refuse to deposit a Pokémon with this flag set
    u8 isStarterPikachu:1; // Thunder Yellow: the PIKACHU from Oak's Lab (outside the encrypted data, so no checksum)
    u8 isSnagged:1; // Thunder Yellow: taken from a trainer in battle (src/snag.c); same byte, no checksum
    u8 unused:2;
    u8 otName[PLAYER_NAME_LENGTH];
    u8 markings;
    u16 checksum;
    u16 unknown;

    union
    {
        u32 raw[(NUM_SUBSTRUCT_BYTES * 4) / 4]; // *4 because there are 4 substructs, /4 because it's u32, not u8
        union PokemonSubstruct substructs[4];
    } secure;
};

struct Pokemon
{
    struct BoxPokemon box;
    u32 status;
    u8 level;
    u8 mail;
    u16 hp;
    u16 maxHP;
    u16 attack;
    u16 defense;
    u16 speed;
    u16 spAttack;
    u16 spDefense;
};


_Static_assert(sizeof(struct BoxPokemon)==80, "host BoxPokemon layout");
_Static_assert(sizeof(struct Pokemon)==100, "host Pokemon layout");
static struct Pokemon gEnemyParty[PARTY_SIZE], gPlayerParty[PARTY_SIZE];
static struct BoxPokemon boxes[TOTAL_BOXES_COUNT][IN_BOX_COUNT];
static u8 gPlayerPartyCount, currentBox, gSpecialVar_MonBoxId, gSpecialVar_MonBoxPos;
static struct {u8 playerName[8], playerGender, playerTrainerId[4];} sb2, *gSaveBlock2Ptr=&sb2;
static struct {u8 pp;} gBattleMoves[MOVES_COUNT];
static const u8 gPPUpGetMask[4]={3,12,48,192};
static const char *orders[24]={"GAEM","GAME","GEAM","GEMA","GMAE","GMEA",
"AGEM","AGME","AEGM","AEMG","AMGE","AMEG","EGAM","EGMA","EAGM","EAMG",
"EMGA","EMAG","MGAE","MGEA","MAGE","MAEG","MEGA","MEAG"};
static union PokemonSubstruct *GetSubstruct(struct BoxPokemon *m,u32 pid,u8 field)
{static const char kinds[4]={'G','A','E','M'}; int i; for(i=0;i<4;i++)if(orders[pid%24][i]==kinds[field])return &m->secure.substructs[i]; abort();}
static void EncryptBoxMon(struct BoxPokemon *);
static void DecryptBoxMon(struct BoxPokemon *);
static u16 CalculateBoxMonChecksum(struct BoxPokemon *);
static struct BoxPokemon clear(struct BoxPokemon *m)
{struct BoxPokemon q=*m; DecryptBoxMon(&q); assert(CalculateBoxMonChecksum(&q)==m->checksum); return q;}
static u32 GetBoxMonData(struct BoxPokemon *m,s32 field,u8 *out)
{struct BoxPokemon q; union PokemonSubstruct *g,*a,*misc;
 if(field==MON_DATA_SANITY_IS_BAD_EGG)return m->isBadEgg;
 if(field==MON_DATA_OT_NAME){if(out){memcpy(out,m->otName,7);out[7]=EOS;}return 0;}
 if(field==MON_DATA_OT_ID)return m->otId;
 q=clear(m);g=GetSubstruct(&q,q.personality,0);a=GetSubstruct(&q,q.personality,1);misc=GetSubstruct(&q,q.personality,3);
 if(field==MON_DATA_SPECIES)return g->type0.species;
 if(field==MON_DATA_IS_EGG)return misc->type3.isEgg;
 if(field==MON_DATA_OT_GENDER)return misc->type3.otGender;
 if(field==MON_DATA_PP_BONUSES)return g->type0.ppBonuses;
 if(field>=MON_DATA_MOVE1&&field<=MON_DATA_MOVE4)return a->type1.moves[field-MON_DATA_MOVE1];
 if(field>=MON_DATA_PP1&&field<=MON_DATA_PP4)return a->type1.pp[field-MON_DATA_PP1];
 abort();}
static void SetBoxMonData(struct BoxPokemon *m,s32 field,const void *value)
{struct BoxPokemon q=clear(m);union PokemonSubstruct *a=GetSubstruct(&q,q.personality,1);
 assert(field>=MON_DATA_PP1&&field<=MON_DATA_PP4);a->type1.pp[field-MON_DATA_PP1]=*(const u8*)value;
 q.checksum=CalculateBoxMonChecksum(&q);EncryptBoxMon(&q);*m=q;}
static u32 GetMonData(struct Pokemon *m,s32 field,u8 *out){return GetBoxMonData(&m->box,field,out);}
static void SetMonData(struct Pokemon *m,s32 field,const void *value)
{struct BoxPokemon q; if(field==MON_DATA_OT_NAME){memcpy(m->box.otName,value,7);return;}
 assert(field==MON_DATA_OT_GENDER);q=clear(&m->box);GetSubstruct(&q,q.personality,3)->type3.otGender=*(const u8*)value;
 q.checksum=CalculateBoxMonChecksum(&q);EncryptBoxMon(&q);m->box=q;}
static u32 GetPlayerTrainerId(void){u32 id;memcpy(&id,sb2.playerTrainerId,4);return id;}
static u8 StringCompare(u8 *a,u8 *b){while(*a==*b&&*a!=EOS){a++;b++;}return *a!=*b;}
static u16 sendBox;
static u16 VarGet(u16 v){(void)v;return sendBox;}
static void VarSet(u16 v,u16 n){(void)v;sendBox=n;}
static void SetPCBoxToSendMon(u16 n){(void)n;}
static u8 GetPCBoxToSendMon(void){return (u8)sendBox;}
static u8 StorageGetCurrentBox(void){return currentBox;}
static struct BoxPokemon *GetBoxedMonPtr(u8 b,u8 p){assert(b<14&&p<30);return &boxes[b][p];}
static void FlagClear(u16 n){(void)n;}
void CopyMon(void *,void *,size_t);
void SetBoxMonOtIdReencrypt(struct BoxPokemon *,u32);
u8 CalculatePPWithBonus(u16,u8,u8);
u8 CalculateBoxMonPPWithBonus(struct BoxPokemon *,u16,u8,u8);
bool8 IsOtherTrainer(u32,u8 *);
void MonRestorePP(struct Pokemon *);
void BoxMonRestorePP(struct BoxPokemon *);
u8 GiveMonToPlayer(struct Pokemon *);
u8 SendMonToPC(struct Pokemon *);
static void EncryptBoxMon(struct BoxPokemon *boxMon)
{
    u32 i;
    for (i = 0; i < ARRAY_COUNT(boxMon->secure.raw); i++)
    {
        boxMon->secure.raw[i] ^= boxMon->personality;
        boxMon->secure.raw[i] ^= boxMon->otId;
    }
}
static void DecryptBoxMon(struct BoxPokemon *boxMon)
{
    u32 i;
    for (i = 0; i < ARRAY_COUNT(boxMon->secure.raw); i++)
    {
        boxMon->secure.raw[i] ^= boxMon->otId;
        boxMon->secure.raw[i] ^= boxMon->personality;
    }
}
static u16 CalculateBoxMonChecksum(struct BoxPokemon *boxMon)
{
    u16 checksum = 0;
    union PokemonSubstruct *substruct0 = GetSubstruct(boxMon, boxMon->personality, 0);
    union PokemonSubstruct *substruct1 = GetSubstruct(boxMon, boxMon->personality, 1);
    union PokemonSubstruct *substruct2 = GetSubstruct(boxMon, boxMon->personality, 2);
    union PokemonSubstruct *substruct3 = GetSubstruct(boxMon, boxMon->personality, 3);
    s32 i;

    for (i = 0; i < (s32)ARRAY_COUNT(substruct0->raw); i++)
        checksum += substruct0->raw[i];

    for (i = 0; i < (s32)ARRAY_COUNT(substruct1->raw); i++)
        checksum += substruct1->raw[i];

    for (i = 0; i < (s32)ARRAY_COUNT(substruct2->raw); i++)
        checksum += substruct2->raw[i];

    for (i = 0; i < (s32)ARRAY_COUNT(substruct3->raw); i++)
        checksum += substruct3->raw[i];

    return checksum;
}
void SetBoxMonOtIdReencrypt(struct BoxPokemon *boxMon, u32 otId)
{
    DecryptBoxMon(boxMon);
    boxMon->otId = otId;
    EncryptBoxMon(boxMon);
}
bool8 IsOtherTrainer(u32 otId, u8 *otName)
{
    if (otId ==
        (gSaveBlock2Ptr->playerTrainerId[0]
         | (gSaveBlock2Ptr->playerTrainerId[1] << 8)
         | (gSaveBlock2Ptr->playerTrainerId[2] << 16)
         | (gSaveBlock2Ptr->playerTrainerId[3] << 24)))
    {
        int i;

        for (i = 0; otName[i] != EOS; i++)
            if (otName[i] != gSaveBlock2Ptr->playerName[i])
                return TRUE;
        return FALSE;
    }

    return TRUE;
}
u8 CalculatePPWithBonus(u16 move, u8 ppBonuses, u8 moveIndex)
{
    u8 basePP = gBattleMoves[move].pp;
    return basePP + ((basePP * 20 * ((gPPUpGetMask[moveIndex] & ppBonuses) >> (2 * moveIndex))) / 100);
}
u8 CalculateBoxMonPPWithBonus(struct BoxPokemon *boxMon, u16 move, u8 ppBonuses, u8 moveIndex)
{
    u8 pp, basePP, ups;
    u8 otName[PLAYER_NAME_LENGTH + 1];
    u32 address = (u32)boxMon;

    if (move == MOVE_NONE || move >= MOVES_COUNT || moveIndex >= MAX_MON_MOVES)
        return 0;
    basePP = gBattleMoves[move].pp;
    pp = CalculatePPWithBonus(move, ppBonuses, moveIndex);
    // Wild and NPC parties can also have the player's original trainer ID.
    if (address >= (u32)gEnemyParty && address < (u32)(gEnemyParty + PARTY_SIZE))
        return pp;
    if (GetBoxMonData(boxMon, MON_DATA_SANITY_IS_BAD_EGG, NULL)
     || GetBoxMonData(boxMon, MON_DATA_IS_EGG, NULL))
        return pp;
    GetBoxMonData(boxMon, MON_DATA_OT_NAME, otName);
    if (IsOtherTrainer(GetBoxMonData(boxMon, MON_DATA_OT_ID, NULL), otName)
     || StringCompare(otName, gSaveBlock2Ptr->playerName) != 0
     || GetBoxMonData(boxMon, MON_DATA_OT_GENDER, NULL) != gSaveBlock2Ptr->playerGender)
        return pp;
    ups = (ppBonuses >> (2 * moveIndex)) & 3;
    if (GetBoxMonData(boxMon, MON_DATA_SPECIES, NULL) == SPECIES_PIKACHU)
    {
        // Apply the normal PP Up increments to the raised base, with no plateau.
        if (basePP < 15)
            basePP = 15;
        return basePP + basePP * ups / 5;
    }
    if (ups == 3 && basePP >= 5 && pp < 15)
        return 15;
    return pp;
}
void CopyMon(void *dest, void *src, size_t size)
{
    memcpy(dest, src, size);
}
void MonRestorePP(struct Pokemon *mon)
{
    BoxMonRestorePP(&mon->box);
}
void BoxMonRestorePP(struct BoxPokemon *boxMon)
{
    int i;

    for (i = 0; i < MAX_MON_MOVES; i++)
    {
        if (GetBoxMonData(boxMon, MON_DATA_MOVE1 + i, 0))
        {
            u16 move = GetBoxMonData(boxMon, MON_DATA_MOVE1 + i, 0);
            u16 bonus = GetBoxMonData(boxMon, MON_DATA_PP_BONUSES, 0);
            u8 pp = CalculateBoxMonPPWithBonus(boxMon, move, bonus, i);
            SetBoxMonData(boxMon, MON_DATA_PP1 + i, &pp);
        }
    }
}
u8 SendMonToPC(struct Pokemon* mon)
{
    s32 boxNo, boxPos;

    SetPCBoxToSendMon(VarGet(VAR_PC_BOX_TO_SEND_MON));

    boxNo = StorageGetCurrentBox();

    do
    {
        for (boxPos = 0; boxPos < IN_BOX_COUNT; boxPos++)
        {
            struct BoxPokemon* checkingMon = GetBoxedMonPtr(boxNo, boxPos);
            if (GetBoxMonData(checkingMon, MON_DATA_SPECIES, NULL) == SPECIES_NONE)
            {
                MonRestorePP(mon);
                CopyMon(checkingMon, &mon->box, sizeof(mon->box));
                BoxMonRestorePP(checkingMon);
                gSpecialVar_MonBoxId = boxNo;
                gSpecialVar_MonBoxPos = boxPos;
                if (GetPCBoxToSendMon() != boxNo)
                    FlagClear(FLAG_SHOWN_BOX_WAS_FULL_MESSAGE);
                VarSet(VAR_PC_BOX_TO_SEND_MON, boxNo);
                return MON_GIVEN_TO_PC;
            }
        }

        boxNo++;
        if (boxNo == TOTAL_BOXES_COUNT)
            boxNo = 0;
    } while (boxNo != StorageGetCurrentBox());

    return MON_CANT_GIVE;
}
u8 GiveMonToPlayer(struct Pokemon *mon)
{
    s32 i;

    SetMonData(mon, MON_DATA_OT_NAME, gSaveBlock2Ptr->playerName);
    SetMonData(mon, MON_DATA_OT_GENDER, &gSaveBlock2Ptr->playerGender);
    // The OT is part of the encryption key; preserve the existing secure data.
    SetBoxMonOtIdReencrypt(&mon->box, GetPlayerTrainerId());

    for (i = 0; i < PARTY_SIZE; i++)
    {
        if (GetMonData(&gPlayerParty[i], MON_DATA_SPECIES, NULL) == SPECIES_NONE)
            break;
    }

    if (i >= PARTY_SIZE)
        return SendMonToPC(mon);

    CopyMon(&gPlayerParty[i], mon, sizeof(*mon));
    gPlayerPartyCount = i + 1;
    return MON_GIVEN_TO_PARTY;
}
static const u8 fixture80[80]={149,147,11,223,122,251,58,169,202,195,197,187,189,194,207,255,64,115,2,2,196,195,194,187,200,255,255,0,123,130,0,0,246,104,134,118,132,223,52,118,239,151,49,118,239,48,180,84,253,63,254,65,239,232,49,118,143,87,11,153,196,99,49,118,239,104,49,118,238,104,51,118,236,104,53,118,237,107,53,115};
static unsigned cases;
static void fixture(struct Pokemon *m,u8 bonus,int isEgg,int foreign)
{struct BoxPokemon q;memset(m,0,sizeof(*m));memcpy(&m->box,fixture80,80);
 q=clear(&m->box);GetSubstruct(&q,q.personality,0)->type0.ppBonuses=bonus;
 GetSubstruct(&q,q.personality,3)->type3.isEgg=isEgg;q.isEgg=isEgg;
 q.checksum=CalculateBoxMonChecksum(&q);EncryptBoxMon(&q);m->box=q;
 if(foreign)SetBoxMonOtIdReencrypt(&m->box,GetPlayerTrainerId()^0xa596c30f);}
static void reset(u8 bonus,int isEgg,int foreign)
{unsigned i;memset(boxes,0,sizeof(boxes));sendBox=currentBox=0;
 for(i=0;i<6;i++)fixture(&gPlayerParty[i],0,0,0);gPlayerPartyCount=6;
 fixture(&gEnemyParty[0],bonus,isEgg,foreign);}
static void pp_values(struct BoxPokemon *m,const u8 expected[4])
{unsigned i;for(i=0;i<4;i++)assert(GetBoxMonData(m,MON_DATA_PP1+i,NULL)==expected[i]);assert(!m->isBadEgg);(void)clear(m);}
static void nonPP_secure_equal(struct BoxPokemon *a,struct BoxPokemon *b)
{struct BoxPokemon x=clear(a),y=clear(b);memset(GetSubstruct(&x,x.personality,1)->type1.pp,0,4);
 memset(GetSubstruct(&y,y.personality,1)->type1.pp,0,4);assert(!memcmp(x.secure.raw,y.secure.raw,48));
 assert(a->personality==b->personality&&a->otId==b->otId&&!memcmp(a->nickname,b->nickname,10));}
int main(void)
{unsigned i,up;struct BoxPokemon before;struct Pokemon local;u8 oldEnemyPP[4];
 memcpy(sb2.playerName,((const struct BoxPokemon*)fixture80)->otName,7);sb2.playerName[7]=EOS;
 memcpy(sb2.playerTrainerId,fixture80+4,4);{struct Pokemon m;fixture(&m,0,0,0);sb2.playerGender=(u8)GetMonData(&m,MON_DATA_OT_GENDER,NULL);}
 assert((u32)(uintptr_t)(gEnemyParty+6)>(u32)(uintptr_t)gEnemyParty);
 assert(!((u32)(uintptr_t)&boxes[0][0]>=(u32)(uintptr_t)gEnemyParty&&(u32)(uintptr_t)&boxes[0][0]<(u32)(uintptr_t)(gEnemyParty+6)));
 gBattleMoves[1].pp=5;gBattleMoves[2].pp=10;gBattleMoves[3].pp=15;gBattleMoves[4].pp=40;
 for(up=0;up<4;up++){
   u8 bonus=(u8)(up*0x55),stock[4],owned[4],wanted[4];reset(bonus,0,0);
   for(i=0;i<4;i++){u8 base=gBattleMoves[i+1].pp;stock[i]=(u8)(base+base*up/5);base=base<15?15:base;owned[i]=(u8)(base+base*up/5);wanted[i]=1?owned[i]:stock[i];
     assert(CalculateBoxMonPPWithBonus(&gEnemyParty[0].box,(u16)(i+1),bonus,(u8)i)==stock[i]);}
   before=gEnemyParty[0].box;assert(GiveMonToPlayer(&gEnemyParty[0])==MON_GIVEN_TO_PC);pp_values(&boxes[0][0],wanted);nonPP_secure_equal(&before,&boxes[0][0]);
   for(i=0;i<4;i++)oldEnemyPP[i]=(u8)GetMonData(&gEnemyParty[0],MON_DATA_PP1+i,NULL);pp_values(&gEnemyParty[0].box,stock);cases++;
 }
 reset(0,0,0);fixture(&local,0,0,0);assert(SendMonToPC(&local)==MON_GIVEN_TO_PC);{const u8 own[4]={15,15,15,40};pp_values(&boxes[0][0],own);}cases++;
 reset(0,0,1);assert(SendMonToPC(&gEnemyParty[0])==MON_GIVEN_TO_PC);{const u8 stock[4]={5,10,15,40};pp_values(&boxes[0][0],stock);}cases++;
 reset(0,1,0);assert(SendMonToPC(&gEnemyParty[0])==MON_GIVEN_TO_PC);{const u8 stock[4]={5,10,15,40};pp_values(&boxes[0][0],stock);}cases++;
 reset(0,0,0);assert(CalculateBoxMonPPWithBonus(&gEnemyParty[0].box,355,0,0)==0);assert(CalculateBoxMonPPWithBonus(&gEnemyParty[0].box,1,0,4)==0);cases++;
 reset(0,0,0);for(i=0;i<420;i++)boxes[i/30][i%30]=gPlayerParty[0].box;
 {struct BoxPokemon *backup=malloc(sizeof(boxes));struct Pokemon enemy=gEnemyParty[0];assert(backup);memcpy(backup,boxes,sizeof(boxes));
 assert(SendMonToPC(&gEnemyParty[0])==MON_CANT_GIVE);assert(!memcmp(backup,boxes,sizeof(boxes)));assert(!memcmp(&enemy,&gEnemyParty[0],sizeof(enemy)));free(backup);}cases++;
 printf("{\"host_component_pass\":true,\"cases\":%u,\"candidate\":%s,\"native_GBA_capture\":false,\"BadEgg_cause_proven\":false}\n",cases,1?"true":"false");return 0;}
