static const struct SpriteFrameImage sPicTable_RedNormal[] = {
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 8),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 9),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 10),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 11),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 12),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 13),
};

static const struct SpriteFrameImage sPicTable_RedBike[] = {
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 5),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 6),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 7),
    overworld_frame(gObjectEventPic_RedBike, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GreenNormal[] = {
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 8),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 9),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 10),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 11),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 12),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 13),
};

static const struct SpriteFrameImage sPicTable_GreenBike[] = {
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 5),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 6),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 7),
    overworld_frame(gObjectEventPic_GreenBike, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedSurf[] = {
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedSurfRun, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_GreenSurf[] = {
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenSurfRun, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_RedItem[] = {
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 0),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 1),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 2),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 3),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 4),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 5),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 6),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 7),
    overworld_frame(gObjectEventPic_RedItem, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_GreenItem[] = {
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 0),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 1),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 2),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 3),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 4),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 5),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 6),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 7),
    overworld_frame(gObjectEventPic_GreenItem, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedVSSeekerBike[] = {
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedVSSeekerBike, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_GreenVSSeekerBike[] = {
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenVSSeekerBike, 4, 4, 5),
};

static const struct SpriteFrameImage sPicTable_RSBrendan[] = {
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 0),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 1),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 2),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 3),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 4),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 5),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 6),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 7),
    overworld_frame(gObjectEventPic_RSBrendan, 2, 4, 8),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_RSMay[] = {
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 0),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 1),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 2),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 3),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 4),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 5),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 6),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 7),
    overworld_frame(gObjectEventPic_RSMay, 2, 4, 8),
    overworld_frame(gObjectEventPic_RedFish, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Policeman[] = {
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 0),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 1),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 2),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 3),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 4),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 5),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 6),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 7),
    overworld_frame(gObjectEventPic_Policeman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_LittleBoy[] = {
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 0),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 1),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 2),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 3),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 4),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 5),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 6),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 7),
    overworld_frame(gObjectEventPic_LittleBoy, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_LittleGirl[] = {
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 0),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 1),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 2),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 3),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 4),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 5),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 6),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 7),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 8),
    overworld_frame(gObjectEventPic_LittleGirl, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_SittingBoy[] = {
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
    overworld_frame(gObjectEventPic_SittingBoy, 2, 4, 1),
};

static const struct SpriteFrameImage sPicTable_Lass[] = {
    overworld_frame(gObjectEventPic_Lass, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 8),
    overworld_frame(gObjectEventPic_Lass, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Youngster[] = {
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 0),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 1),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 2),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 3),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 4),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 5),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 6),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 7),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 8),
    overworld_frame(gObjectEventPic_Youngster, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman1[] = {
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 8),
    overworld_frame(gObjectEventPic_Woman1, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman3[] = {
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman3, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_CrushGirl[] = {
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 0),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 1),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 2),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 3),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 4),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 5),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 6),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 7),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 8),
    overworld_frame(gObjectEventPic_CrushGirl, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_BugCatcher[] = {
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 0),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 1),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 2),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 3),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 4),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 5),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 6),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 7),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 8),
    overworld_frame(gObjectEventPic_BugCatcher, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_FatMan[] = {
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 2),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 3),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 4),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 5),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 6),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 7),
    overworld_frame(gObjectEventPic_FatMan, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_BaldingMan[] = {
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 0),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 1),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 2),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 3),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 4),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 5),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 6),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 7),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 8),
    overworld_frame(gObjectEventPic_BaldingMan, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Woman2[] = {
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 0),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 1),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 2),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 3),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 4),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 5),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 6),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 7),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 8),
    overworld_frame(gObjectEventPic_Woman2, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_OldMan1[] = {
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 8),
    overworld_frame(gObjectEventPic_OldMan1, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_WorkerM[] = {
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_WorkerF[] = {
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 0),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 1),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 2),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 3),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 4),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 5),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 6),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 7),
    overworld_frame(gObjectEventPic_WorkerF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Beauty[] = {
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 2),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 3),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 4),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 5),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 6),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 7),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 8),
    overworld_frame(gObjectEventPic_Beauty, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Chef[] = {
    overworld_frame(gObjectEventPic_Chef, 2, 4, 0),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 1),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 2),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 3),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 4),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 5),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 6),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 7),
    overworld_frame(gObjectEventPic_Chef, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_OldMan2[] = {
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldMan2, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_OldManLyingDown[] = {
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
    overworld_frame(gObjectEventPic_OldManLyingDown, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_OldWoman[] = {
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 0),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 1),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 2),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 3),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 4),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 5),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 6),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 7),
    overworld_frame(gObjectEventPic_OldWoman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Camper[] = {
    overworld_frame(gObjectEventPic_Camper, 2, 4, 0),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 1),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 2),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 3),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 4),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 5),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 6),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 7),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 8),
    overworld_frame(gObjectEventPic_Camper, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Picnicker[] = {
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 0),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 1),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 2),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 3),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 4),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 5),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 6),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 7),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 8),
    overworld_frame(gObjectEventPic_Picnicker, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_CooltrainerM[] = {
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 8),
    overworld_frame(gObjectEventPic_CooltrainerM, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_CooltrainerF[] = {
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 0),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 1),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 2),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 3),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 4),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 5),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 6),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 7),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 8),
    overworld_frame(gObjectEventPic_CooltrainerF, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Boy[] = {
    overworld_frame(gObjectEventPic_Boy, 2, 4, 0),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 1),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 2),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 3),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 4),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 5),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 6),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 7),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 8),
    overworld_frame(gObjectEventPic_Boy, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_PokeManiac[] = {
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 0),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 1),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 2),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 3),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 4),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 5),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 6),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 7),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 8),
    overworld_frame(gObjectEventPic_PokeManiac, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Channeler[] = {
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 0),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 1),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 2),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 3),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 4),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 5),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 6),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 7),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 8),
    overworld_frame(gObjectEventPic_Channeler, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_RocketF[] = {
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Jessie[] = {
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 0),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 1),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 2),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 3),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 4),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 5),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 6),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 7),
    overworld_frame(gObjectEventPic_Jessie, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_James[] = {
    overworld_frame(gObjectEventPic_James, 2, 4, 0),
    overworld_frame(gObjectEventPic_James, 2, 4, 1),
    overworld_frame(gObjectEventPic_James, 2, 4, 2),
    overworld_frame(gObjectEventPic_James, 2, 4, 3),
    overworld_frame(gObjectEventPic_James, 2, 4, 4),
    overworld_frame(gObjectEventPic_James, 2, 4, 5),
    overworld_frame(gObjectEventPic_James, 2, 4, 6),
    overworld_frame(gObjectEventPic_James, 2, 4, 7),
    overworld_frame(gObjectEventPic_James, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_CapsuleShards[] = {
    overworld_frame(gObjectEventPic_CapsuleShards, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Truck[] = {
    overworld_frame(gObjectEventPic_Truck, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Airplane[] = {
    overworld_frame(gObjectEventPic_Airplane, 4, 4, 0),
    overworld_frame(gObjectEventPic_Airplane, 4, 4, 1),
    overworld_frame(gObjectEventPic_Airplane, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_AirplaneSmall[] = {
    overworld_frame(gObjectEventPic_AirplaneSmall, 2, 2, 0),
    overworld_frame(gObjectEventPic_AirplaneSmall, 2, 2, 1),
    overworld_frame(gObjectEventPic_AirplaneSmall, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_SwimmerMWater[] = {
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerMWater, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerFWater[] = {
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerFWater, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerMLand[] = {
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerMLand, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_SwimmerFLand[] = {
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 0),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 1),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 2),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 3),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 4),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 5),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 6),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 7),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 8),
    overworld_frame(gObjectEventPic_SwimmerFLand, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_BlackBelt[] = {
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 0),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 1),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 2),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 3),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 4),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 5),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 6),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 7),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 8),
    overworld_frame(gObjectEventPic_BlackBelt, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Scientist[] = {
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 0),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 1),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 2),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 3),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 4),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 5),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 6),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 7),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 8),
    overworld_frame(gObjectEventPic_Scientist, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Gentleman[] = {
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 0),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 1),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 2),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 3),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 4),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 5),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 6),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 7),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 8),
    overworld_frame(gObjectEventPic_Gentleman, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Sailor[] = {
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 3),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 4),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 5),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 6),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 7),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 8),
    overworld_frame(gObjectEventPic_Sailor, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Captain[] = {
    overworld_frame(gObjectEventPic_Captain, 2, 4, 0),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 1),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 2),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 3),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 4),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 5),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 6),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 7),
    overworld_frame(gObjectEventPic_Captain, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Fisher[] = {
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 0),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 1),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 2),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 3),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 4),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 5),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 6),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 7),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 8),
    overworld_frame(gObjectEventPic_Fisher, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_TeachyTVHost[] = {
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 0),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 1),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 2),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 3),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 4),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 5),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 6),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 7),
    overworld_frame(gObjectEventPic_TeachyTVHost, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_UnusedWoman[] = {
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 3),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 4),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 5),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 6),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 7),
    overworld_frame(gObjectEventPic_UnusedWoman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_TuberF[] = {
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberF, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_TuberMWater[] = {
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberMWater, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_TuberMLand[] = {
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 0),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 1),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 2),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 3),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 4),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 5),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 6),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 7),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 8),
    overworld_frame(gObjectEventPic_TuberMLand, 2, 2, 9),
};

static const struct SpriteFrameImage sPicTable_Hiker[] = {
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 0),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 1),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 2),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 3),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 4),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 5),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 6),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 7),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 8),
    overworld_frame(gObjectEventPic_Hiker, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Biker[] = {
    overworld_frame(gObjectEventPic_Biker, 4, 4, 0),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 1),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 2),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 3),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 4),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 5),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 6),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 7),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 8),
    overworld_frame(gObjectEventPic_Biker, 4, 4, 9),
};

static const struct SpriteFrameImage sPicTable_GymGuy[] = {
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 0),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 1),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 2),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 3),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 4),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 5),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 6),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 7),
    overworld_frame(gObjectEventPic_GymGuy, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Nurse[] = {
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 0),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 1),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 2),
    overworld_frame(gObjectEventPic_Nurse, 2, 4, 3),
};

static const struct SpriteFrameImage sPicTable_UnusedMaleReceptionist[] = {
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnusedMaleReceptionist, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_ItemBall[] = {
    overworld_frame(gObjectEventPic_ItemBall, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_ProfOak[] = {
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 0),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 1),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 2),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 3),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 4),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 5),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 6),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 7),
    overworld_frame(gObjectEventPic_ProfOak, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Man[] = {
    overworld_frame(gObjectEventPic_Man, 2, 4, 0),
    overworld_frame(gObjectEventPic_Man, 2, 4, 1),
    overworld_frame(gObjectEventPic_Man, 2, 4, 2),
    overworld_frame(gObjectEventPic_Man, 2, 4, 3),
    overworld_frame(gObjectEventPic_Man, 2, 4, 4),
    overworld_frame(gObjectEventPic_Man, 2, 4, 5),
    overworld_frame(gObjectEventPic_Man, 2, 4, 6),
    overworld_frame(gObjectEventPic_Man, 2, 4, 7),
    overworld_frame(gObjectEventPic_Man, 2, 4, 8),
    overworld_frame(gObjectEventPic_Man, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_Rocker[] = {
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 0),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 1),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 2),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 3),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 4),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 5),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 6),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 7),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 8),
    overworld_frame(gObjectEventPic_Rocker, 2, 4, 9),
};

static const struct SpriteFrameImage sPicTable_MrFuji[] = {
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 0),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 1),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 2),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 3),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 4),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 5),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 6),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 7),
    overworld_frame(gObjectEventPic_MrFuji, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Bruno[] = {
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bruno, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_CutTree[] = {
    overworld_frame(gObjectEventPic_CutTree, 2, 2, 0),
    overworld_frame(gObjectEventPic_CutTree, 2, 2, 1),
    overworld_frame(gObjectEventPic_CutTree, 2, 2, 2),
    overworld_frame(gObjectEventPic_CutTree, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_Clerk[] = {
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 0),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 1),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 2),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 3),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 4),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 5),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 6),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 7),
    overworld_frame(gObjectEventPic_Clerk, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_MGDeliveryman[] = {
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 0),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 1),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
    overworld_frame(gObjectEventPic_MGDeliveryman, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_TrainerTowerDude[] = {
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 0),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 1),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
    overworld_frame(gObjectEventPic_TrainerTowerDude, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_CableClubReceptionist[] = {
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_CableClubReceptionist, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_UnionRoomReceptionist[] = {
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 0),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 1),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
    overworld_frame(gObjectEventPic_UnionRoomReceptionist, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_RockSmashRock[] = {
    overworld_frame(gObjectEventPic_RockSmashRock, 2, 2, 0),
    overworld_frame(gObjectEventPic_RockSmashRock, 2, 2, 1),
    overworld_frame(gObjectEventPic_RockSmashRock, 2, 2, 2),
    overworld_frame(gObjectEventPic_RockSmashRock, 2, 2, 3),
};

static const struct SpriteFrameImage sPicTable_StrengthBoulder[] = {
    overworld_frame(gObjectEventPic_StrengthBoulder, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_RocketM[] = {
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 0),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 1),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 2),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 3),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 4),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 5),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 6),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 7),
    overworld_frame(gObjectEventPic_RocketM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Celio[] = {
    overworld_frame(gObjectEventPic_Celio, 2, 4, 0),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 1),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 2),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 3),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 4),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 5),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 6),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 7),
    overworld_frame(gObjectEventPic_Celio, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Agatha[] = {
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 0),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 1),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
    overworld_frame(gObjectEventPic_Agatha, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Brock[] = {
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 0),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 1),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
    overworld_frame(gObjectEventPic_Brock, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Misty[] = {
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 0),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 1),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
    overworld_frame(gObjectEventPic_Misty, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_LtSurge[] = {
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 0),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 1),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
    overworld_frame(gObjectEventPic_LtSurge, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Erika[] = {
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 0),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 1),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
    overworld_frame(gObjectEventPic_Erika, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Koga[] = {
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 0),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 1),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
    overworld_frame(gObjectEventPic_Koga, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Giovanni[] = {
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 0),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 1),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 2),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 3),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 4),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 5),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 6),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 7),
    overworld_frame(gObjectEventPic_Giovanni, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Blaine[] = {
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blaine, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Sabrina[] = {
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 0),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 1),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
    overworld_frame(gObjectEventPic_Sabrina, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Bill[] = {
    overworld_frame(gObjectEventPic_Bill, 2, 4, 0),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 1),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 2),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 3),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 4),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 5),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 6),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 7),
    overworld_frame(gObjectEventPic_Bill, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Daisy[] = {
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 0),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 1),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 2),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 3),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 4),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 5),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 6),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 7),
    overworld_frame(gObjectEventPic_Daisy, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lorelei[] = {
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 3),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 4),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 5),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 6),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 7),
    overworld_frame(gObjectEventPic_Lorelei, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_Lance[] = {
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 0),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 1),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
    overworld_frame(gObjectEventPic_Lance, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Blue[] = {
    overworld_frame(gObjectEventPic_Blue, 2, 4, 0),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 1),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 2),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 3),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 4),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 5),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 6),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 7),
    overworld_frame(gObjectEventPic_Blue, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_RedFish[] = {
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 0),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 1),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 2),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 3),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 4),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 5),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 6),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 7),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 8),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 9),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 10),
    overworld_frame(gObjectEventPic_RedFish, 4, 4, 11),
};

static const struct SpriteFrameImage sPicTable_GreenFish[] = {
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 0),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 1),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 2),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 3),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 4),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 5),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 6),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 7),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 8),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 9),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 10),
    overworld_frame(gObjectEventPic_GreenFish, 4, 4, 11),
};

static const struct SpriteFrameImage sPicTable_TownMap[] = {
    overworld_frame(gObjectEventPic_TownMap, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Pokedex[] = {
    overworld_frame(gObjectEventPic_Pokedex, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_GBAKid[] = {
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 0),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 1),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
    overworld_frame(gObjectEventPic_GBAKid, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Fossil[] = {
    overworld_frame(gObjectEventPic_Fossil, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Ruby[] = {
    overworld_frame(gObjectEventPic_Ruby, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Sapphire[] = {
    overworld_frame(gObjectEventPic_Sapphire, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_OldAmber[] = {
    overworld_frame(gObjectEventPic_OldAmber, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_GymSign[] = {
    overworld_frame(gObjectEventPic_GymSign, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Sign[] = {
    overworld_frame(gObjectEventPic_Sign, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_WoodenSign[] = {
    overworld_frame(gObjectEventPic_WoodenSign, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Clipboard[] = {
    overworld_frame(gObjectEventPic_Clipboard, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_BirthIslandStone[] = {
    overworld_frame(gObjectEventPic_BirthIslandStone, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_LaprasDoll[] = {
    overworld_frame(gObjectEventPic_LaprasDoll, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Seagallop[] = {
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
    overworld_frame(gObjectEventPic_Seagallop, 4, 16, 0),
};

static const struct SpriteFrameImage sPicTable_SSAnne[] = {
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
    overworld_frame(gObjectEventPic_SSAnne, 8, 16, 0),
};

static const struct SpriteFrameImage sPicTable_Snorlax[] = {
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
    overworld_frame(gObjectEventPic_Snorlax, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Spearow[] = {
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 2),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 2),
    overworld_frame(gObjectEventPic_Spearow, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Pidgeot[] = {
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 2),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 2),
    overworld_frame(gObjectEventPic_Pidgeot, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Omanyte[] = {
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 0),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 1),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 2),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 0),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 0),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 1),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 1),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 2),
    overworld_frame(gObjectEventPic_Omanyte, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Kangaskhan[] = {
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 2),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 2),
    overworld_frame(gObjectEventPic_Kangaskhan, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Psyduck[] = {
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 0),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 1),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 2),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 0),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 0),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 1),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 1),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 2),
    overworld_frame(gObjectEventPic_Psyduck, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_NidoranF[] = {
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranF, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_NidoranM[] = {
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 0),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 1),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 2),
    overworld_frame(gObjectEventPic_NidoranM, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Nidorino[] = {
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 0),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 1),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 2),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 0),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 0),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 1),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 1),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 2),
    overworld_frame(gObjectEventPic_Nidorino, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Meowth[] = {
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 0),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 1),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 2),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 0),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 0),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 1),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 1),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 2),
    overworld_frame(gObjectEventPic_Meowth, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Seel[] = {
    overworld_frame(gObjectEventPic_Seel, 2, 2, 0),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 1),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 2),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 0),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 0),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 1),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 1),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 2),
    overworld_frame(gObjectEventPic_Seel, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Voltorb[] = {
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 0),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 1),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 2),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 0),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 0),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 1),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 1),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 2),
    overworld_frame(gObjectEventPic_Voltorb, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Slowpoke[] = {
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 2),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 2),
    overworld_frame(gObjectEventPic_Slowpoke, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Slowbro[] = {
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 2),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 0),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 1),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 2),
    overworld_frame(gObjectEventPic_Slowbro, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Machop[] = {
    overworld_frame(gObjectEventPic_Machop, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 2),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 2),
    overworld_frame(gObjectEventPic_Machop, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Wigglytuff[] = {
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 2),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 2),
    overworld_frame(gObjectEventPic_Wigglytuff, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Doduo[] = {
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 1),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 2),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 1),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 1),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 2),
    overworld_frame(gObjectEventPic_Doduo, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Fearow[] = {
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 2),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 0),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 1),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 2),
    overworld_frame(gObjectEventPic_Fearow, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Lapras[] = {
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 0),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 1),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 2),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 0),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 0),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 1),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 1),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 2),
    overworld_frame(gObjectEventPic_Lapras, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Zapdos[] = {
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
    overworld_frame(gObjectEventPic_Zapdos, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Moltres[] = {
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
    overworld_frame(gObjectEventPic_Moltres, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Articuno[] = {
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
    overworld_frame(gObjectEventPic_Articuno, 4, 4, 0),
};

static const struct SpriteFrameImage sPicTable_DeoxysD[] = {
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysD, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_DeoxysA[] = {
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysA, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_DeoxysN[] = {
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 0),
    overworld_frame(gObjectEventPic_DeoxysN, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_Mewtwo[] = {
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mewtwo, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Mew[] = {
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
    overworld_frame(gObjectEventPic_Mew, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Entei[] = {
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
    overworld_frame(gObjectEventPic_Entei, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Raikou[] = {
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
    overworld_frame(gObjectEventPic_Raikou, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Suicune[] = {
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
    overworld_frame(gObjectEventPic_Suicune, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Lugia[] = {
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 1),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 1),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 0),
    overworld_frame(gObjectEventPic_Lugia, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_HoOh[] = {
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoOh, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_Celebi[] = {
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Celebi, 2, 2, 0),
};

static const struct SpriteFrameImage sPicTable_Cubone[] = {
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 0),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 1),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 2),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 0),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 0),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 1),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 1),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 2),
    overworld_frame(gObjectEventPic_Cubone, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Poliwrath[] = {
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 0),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 1),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 2),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 0),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 0),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 1),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 1),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 2),
    overworld_frame(gObjectEventPic_Poliwrath, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Chansey[] = {
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 2),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 2),
    overworld_frame(gObjectEventPic_Chansey, 2, 2, 2),
};

// Frames 3-8 are walking frames drawn for the following starter PIKACHU;
// FR/LG's sprite only had the three standing frames.
static const struct SpriteFrameImage sPicTable_Pikachu[] = {
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 2),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 3),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 4),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 5),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 6),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 7),
    overworld_frame(gObjectEventPic_Pikachu, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_Jigglypuff[] = {
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 2),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 0),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 1),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 2),
    overworld_frame(gObjectEventPic_Jigglypuff, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Pidgey[] = {
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 2),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 0),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 1),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 2),
    overworld_frame(gObjectEventPic_Pidgey, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Clefairy[] = {
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 2),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 2),
    overworld_frame(gObjectEventPic_Clefairy, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Machoke[] = {
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 2),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 0),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 1),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 2),
    overworld_frame(gObjectEventPic_Machoke, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Kabuto[] = {
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 2),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 0),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 1),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 2),
    overworld_frame(gObjectEventPic_Kabuto, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_Mom[] = {
    overworld_frame(gObjectEventPic_Mom, 2, 4, 0),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 1),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 2),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 0),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 0),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 1),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 1),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 2),
    overworld_frame(gObjectEventPic_Mom, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_Plusle[] = {
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 0),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 1),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 2),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 3),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 4),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 5),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 6),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 7),
    overworld_frame(gObjectEventPic_Plusle, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_Minun[] = {
    overworld_frame(gObjectEventPic_Minun, 2, 2, 0),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 1),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 2),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 3),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 4),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 5),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 6),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 7),
    overworld_frame(gObjectEventPic_Minun, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_Togepi[] = {
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 1),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 2),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 0),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 1),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 1),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 2),
    overworld_frame(gObjectEventPic_Togepi, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_OakTrophy[] = {
    overworld_frame(gObjectEventPic_OakTrophy, 2, 4, 0),
};

static const struct SpriteFrameImage sPicTable_Clefable[] = {
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 2),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 0),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 1),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 2),
    overworld_frame(gObjectEventPic_Clefable, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_MoonStone[] = {
    overworld_frame(gObjectEventPic_MoonStone, 2, 2, 0),
};

// BEGIN HOENN OBJECT EVENTS (generated by tools/hoenn_import/import_objevent_gfx.py)
static const struct SpriteFrameImage sPicTable_HoennAquaMemberM[] = {
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennAquaMemberM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennAquaMemberF[] = {
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennAquaMemberF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennMagmaMemberM[] = {
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennMagmaMemberM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennMagmaMemberF[] = {
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennMagmaMemberF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennArchie[] = {
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennArchie, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennMaxie[] = {
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennMaxie, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennSteven[] = {
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennSteven, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennScott[] = {
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennScott, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennWally[] = {
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennWally, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennProfBirch[] = {
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennProfBirch, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennBrendanNormal[] = {
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennBrendanNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennBrendanRunning, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennMayNormal[] = {
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennMayNormal, 2, 4, 8),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennMayRunning, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennRoxanne[] = {
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennRoxanne, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennBrawly[] = {
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennBrawly, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennWattson[] = {
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWattson, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennFlannery[] = {
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennFlannery, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennNorman[] = {
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennNorman, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennWinona[] = {
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWinona, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennTate[] = {
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennTate, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennLiza[] = {
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennLiza, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennJuan[] = {
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennJuan, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennWallace[] = {
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennWallace, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennSidney[] = {
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennSidney, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennPhoebe[] = {
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennPhoebe, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennGlacia[] = {
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennGlacia, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennDrake[] = {
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennDrake, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennNinjaBoy[] = {
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 3),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 4),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 5),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 6),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 7),
    overworld_frame(gObjectEventPic_HoennNinjaBoy, 2, 2, 8),
};

static const struct SpriteFrameImage sPicTable_HoennHexManiac[] = {
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennHexManiac, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennRichBoy[] = {
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennRichBoy, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennSchoolKidM[] = {
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennSchoolKidM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennCyclingTriathleteM[] = {
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 5),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 6),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 7),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteM, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennCyclingTriathleteF[] = {
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 5),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 6),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 7),
    overworld_frame(gObjectEventPic_HoennCyclingTriathleteF, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennRunningTriathleteM[] = {
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteM, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennRunningTriathleteF[] = {
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennRunningTriathleteF, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennDevonEmployee[] = {
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennDevonEmployee, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennContestJudge[] = {
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennContestJudge, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennKecleon[] = {
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennKecleon, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_HoennWingull[] = {
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 4),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 3),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 3),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 5),
    overworld_frame(gObjectEventPic_HoennWingull, 2, 2, 5),
};

static const struct SpriteFrameImage sPicTable_HoennPoochyena[] = {
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 5),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 6),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 7),
    overworld_frame(gObjectEventPic_HoennPoochyena, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennEnemyZigzagoon[] = {
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 5),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 6),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 7),
    overworld_frame(gObjectEventPic_HoennEnemyZigzagoon, 4, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennZigzagoon[] = {
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennZigzagoon, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_HoennAzurill[] = {
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennAzurill, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_HoennAzumarill[] = {
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennAzumarill, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_HoennSkitty[] = {
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 0),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 1),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 2),
    overworld_frame(gObjectEventPic_HoennSkitty, 2, 2, 2),
};

static const struct SpriteFrameImage sPicTable_HoennSudowoodo[] = {
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennSudowoodo, 2, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennKirlia[] = {
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennKirlia, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennDusclops[] = {
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 0),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 1),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 2),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 3),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 4),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 5),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 6),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 7),
    overworld_frame(gObjectEventPic_HoennDusclops, 2, 4, 8),
};

static const struct SpriteFrameImage sPicTable_HoennVigorothCarryingBox[] = {
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennVigorothFacingAway[] = {
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 3),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
    overworld_frame(gObjectEventPic_HoennVigoroth, 4, 4, 4),
};

static const struct SpriteFrameImage sPicTable_HoennSSTidal[] = {
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
    obj_frame_tiles(gObjectEventPic_HoennSSTidal),
};

static const struct SpriteFrameImage sPicTable_HoennMrBrineysBoat[] = {
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 0),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 1),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 2),
    overworld_frame(gObjectEventPic_HoennMrBrineysBoat, 4, 4, 2),
};

static const struct SpriteFrameImage sPicTable_HoennCableCar[] = {
    obj_frame_tiles(gObjectEventPic_HoennCableCar),
};

static const struct SpriteFrameImage sPicTable_HoennSubmarineShadow[] = {
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
    obj_frame_tiles(gObjectEventPic_HoennSubmarineShadow),
};

static const struct SpriteFrameImage sPicTable_HoennMovingBox[] = {
    obj_frame_tiles(gObjectEventPic_HoennMovingBox),
};

static const struct SpriteFrameImage sPicTable_HoennStatue[] = {
    obj_frame_tiles(gObjectEventPic_HoennStatue),
};

static const struct SpriteFrameImage sPicTable_HoennBirchsBag[] = {
    obj_frame_tiles(gObjectEventPic_HoennBirchsBag),
};

static const struct SpriteFrameImage sPicTable_HoennRegi[] = {
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
    obj_frame_tiles(gObjectEventPic_HoennRegi),
};
// END HOENN OBJECT EVENTS

static const struct SpriteFrameImage sPicTable_JohtoFarfetchd[] = {
    {gMonIcon_Farfetchd, 512},
};

// BEGIN THUNDER YELLOW ORIGINAL HOENN LEGENDS
static const struct SpriteFrameImage sPicTable_ThunderLegendKyogreFront[] = {
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 0),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 0),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 0),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
    overworld_frame(gObjectEventPic_ThunderLegendKyogre, 4, 4, 1),
};

static const struct SpriteFrameImage sPicTable_ThunderLegendRayquaza[] = {
    overworld_frame(gObjectEventPic_ThunderLegendRayquaza, 8, 8, 0),
    overworld_frame(gObjectEventPic_ThunderLegendRayquaza, 8, 8, 1),
    overworld_frame(gObjectEventPic_ThunderLegendRayquaza, 8, 8, 2),
    overworld_frame(gObjectEventPic_ThunderLegendRayquaza, 8, 8, 3),
    overworld_frame(gObjectEventPic_ThunderLegendRayquaza, 8, 8, 4),
};
// END THUNDER YELLOW ORIGINAL HOENN LEGENDS

static const struct SpriteFrameImage sPicTable_JohtoSudowoodo[] = {
    {gMonIcon_Sudowoodo, 512},
};

// Defined in graphics.c; this table is included by event_object_movement.c.
extern const u16 gObjectEventPic_MistyCompanion[];
// Dedicated everyday clothing and alternating walk poses. Index 9 is a safe
// idle fallback for Standard's optional VS Seeker raise-hand animation.
static const struct SpriteFrameImage sPicTable_MistyCompanion[] = {
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 0),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 1),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 2),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 3),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 4),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 5),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 6),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 7),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 8),
    overworld_frame(gObjectEventPic_MistyCompanion, 2, 4, 0),

};

static const struct SpriteFrameImage sPicTable_ProfElmHns[] = {
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 0),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 1),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 2),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 3),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 4),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 5),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 6),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 7),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 8),
    overworld_frame(gObjectEventPic_ProfElmHns, 2, 4, 0),
};
