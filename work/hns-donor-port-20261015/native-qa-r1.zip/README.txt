Elm donor native QA only; no product applies or rebuilds.

Extract this ZIP into work/hns-donor-port-20261015/elm-native-qa-r1/.
After the ten-input donor registration build passes, supply the independently
recorded NEW ROM/ELF SHA256 values below. Existing failed outputs remain intact.

python3 work/hns-donor-port-20261015/elm-native-qa-r1/native_elm_hns_qa_r1.py --root /workspaces/pokefirered --rom /workspaces/pokefirered/pokemonthyl.gba --elf /workspaces/pokefirered/pokemonthyl.elf --sav /workspaces/pokefirered/saves/pokemonthyl_v1.45.sav --out /workspaces/pokefirered/work/hns-donor-port-20261015/elm-native-r1 --expect-rom-sha NEW_ROM_SHA256 --expect-elf-sha NEW_ELF_SHA256 --expect-sav-sha 0949ebf04557a76e2175602e967eefadb7ffb722f2746be8a40ddb1fd66550a9 --verifier /workspaces/pokefirered/work/resume-v145-20261015/route29-misty-integrated-qa-r1/verify_build.py --guard-manifest /workspaces/pokefirered/work/hns-donor-port-20261015/elm-native-qa-r1/elm-native-guard.json --walk-runner /workspaces/pokefirered/work/resume-v145-20261015/route29-misty-native-resume-r3/native_misty_walk_qa_r10.py --elm-manifest /workspaces/pokefirered/work/hns-donor-port-20261015/elm-native-qa-r1/elm-product-manifest.json

The existing R10 source is pinned at 4fe78a90... and only its definitions are
executed. No former eight Misty or ten Route29 cases are repeated.
Existing verifier is pinned at 40647f77... . All constants/offsets are compiled
before boot, and all data symbols are uniquely rebound from the new ELF.
Function addresses are normalized only for ELF kind2.

Scope: unmodified original-save Continue first, then an explicitly separate
preboot ElmLab/story/egg-step-counter fixture. All six party records, PC records
and fourfold Dex bits are retained. Professor gfx238 vs researcher55, original
2304B/32B compiled art, active256B VRAM frame, palette10, three accessible actual
faceplayer interactions, both dynamic followers, actual door roundtrip, real
menu SAVE, all14sector checksums, and live/stored/cold equality are checked.
Followers are required to be visible only after actual trail-filling steps.

East neighbor(8,8) is a cabinet; no impossible east interaction or forced
professor walking is claimed. All nine donor frames are checked in ROM; the
emulator checks naturally reachable idle frames0/1/2. A same-map legacy cached
NPC-template case is applicable only if the original user save is actually
inside ElmLab. Full quest progression and actual DELTA FPS are not covered.
RAM writes, direct engine calls and Save State calls are forbidden.

The preparation-validation.json is offline syntax/source/path evidence only.
It is not evidence that the new ROM was built or that this test ran.
