#!/usr/bin/env python3
"""Run scripted event checks: a save state, key presses, then screenshots and
memory checks, one case per line of a JSON-lines file.

    tools/qa/eventcheck.py tools/qa/cases/z2.jsonl [--shots DIR] [--only NAME]

A case:

    {"name": "wattson_rematch",
     "base": "saves/hoenn.sav",                      (default saves/hoenn.sav)
     "edit": ["warp MauvilleCity_Gym 5 3", "flag FLAG_HOENN_NEW_MAUVILLE_DONE 1"],
     "steps": ["UP", "A*3", "wait 60", "shot rematch", "expect var VAR_X = 2"]}

"edit" lines are savedit.py commands applied to a copy of the base save.
"menu" lines ("poke SYMBOL VALUE", a byte) are written to RAM on the main
menu, before CONTINUE, e.g. gDisableMapMusicChangeOnMapLoad 2 for the real
post-champion credits (the map's playbgm MUS_CREDITS then plays).
"leave_menu_only": true starts the steps as soon as CONTINUE is picked.
Steps, in order:
    A | B | START | SELECT | L | R      press once;  "A*5" presses five times
    UP | DOWN | LEFT | RIGHT [N]         face/walk N tiles (default 1)
    wait N                               run N frames
    mash [N]                             press A (at most N times, default 300)
                                         until the overworld is idle: no battle,
                                         no script running, the player free
    encounter [N]                        walk LEFT and RIGHT (at most N steps,
                                         default 200) until a wild battle starts
    evomash [N]                          press A (at most N times, default 200)
                                         until an evolution scene has come and
                                         gone; fails if none started
    mashto CB2 [N]                       press A (at most N times, default 60)
                                         until gMain.callback2 is CB2
    watch LABEL                          from here on, note whether the text at
                                         ROM label LABEL is shown (gStringVar4,
                                         looked at after every key press); a text
                                         that starts with a placeholder is found
                                         by its longest plain part, in battle
                                         text (gDisplayedStringBattle) too
    mashtext LABEL [N]                   press A (at most N times, default 300)
                                         until the text at LABEL is shown
    waitcb2 CB2 [N]                      run frames (at most N, default 3000) until
                                         gMain.callback2 is CB2, e.g. CB2_Credits
    mashbattle [N]                       press A (at most N times, default 100)
                                         until a battle has started
    throw ITEM [L|R]                     in a battle: wait for the action menu,
                                         BAG, the POKé BALLS pocket, ITEM (the
                                         cursor is moved there from what the bag
                                         remembers), USE; L or R then picks that
                                         opponent with the BALL target cursor
                                         (trainer doubles with both out)
    special NAME [wait]                  run the special NAME (data/specials.inc) as a
                                         script of its own: special, waitstate if
                                         "wait" (specials that start a battle or a
                                         scene and resume the script), releaseall,
                                         end, once the overworld is idle. Tests a
                                         special before any map script calls it
    run                                  wait for the action menu, RUN
    fight N                              wait for the action menu, FIGHT, move N
                                         (1-4); in a double battle A once more
                                         for the first target
    shot NAME                            save NAME.png (in --shots)
    expect flag NAME = 0|1               check a flag in the live game
    expect var NAME = N                  check a var in the live game
    expect trainer NAME = 0|1            check a trainer's beaten flag
    expect money = N                     check the player's money
    expect item ITEM = N                 check how many of ITEM the bag holds
    expect egg SPECIES = N               count EGGS of SPECIES in party and PC
    expect mons SPECIES = N              count SPECIES (not EGGS) in party and PC
    expect fateful SPECIES = N           count SPECIES (EGGS too) in party and PC
                                         with the fateful encounter bit (MEW's
                                         and DEOXYS's obedience)
    expect count SPECIES = N             same as expect mons
    expect mon SPECIES = N               same as expect mons (the v0.11.0 plan's
                                         spelling; "=" tells it from the next form)
    expect mon NAME[|NAME] KEY=VALUE ... some such POKéMON in party or PC matches all
                                         of: ot=NAME, otid=player|N, metloc=
                                         MAPSEC_X|N, metlvl=N, ball=ITEM_X,
                                         snagged=0|1, item=ITEM_X|ITEM_NONE,
                                         where=party|box
    expect dex SPECIES = none|seen|caught  all four dex places agree (caught:
                                         owned + 3 seen; seen: 3 seen, not owned)
    expect enemy SPECIES = N             count SPECIES in gEnemyParty
    expect enemycount = N                count the POKéMON in gEnemyParty
    expect double = 0|1                  a double battle or not
    expect species SLOT NAME[|NAME]      check the species in party SLOT (0-5)
    expect sym NAME = N                  check the byte at a RAM symbol (statics
                                         too, e.g. sClockWindowShown)
    expect deref NAME OFF = N            check the u16 at OFF in the block a RAM
                                         pointer points to (e.g. sCreditsMgr 6 is
                                         the credits script command index)
    expect saw LABEL = 0|1               whether a watched text was shown
    expect text WORDS...                 the message now in gStringVar4 contains
                                         WORDS (plain characters; line breaks
                                         read as spaces)
    expect presses <= N                  A presses the last mash/mashto took
    expect move SLOT MOVE                check that party SLOT knows MOVE
    expect hp SLOT = N|full              party SLOT's current HP (full: = max HP)
    expect cb2 NAME                      check gMain.callback2 (e.g. CB2_UpdatePartyMenu)
    expect map MAP                       check the player's current map
    expect song LABEL                    the BGM player plays the song at LABEL
                                         (e.g. mus_credits), with tracks active
    expect battle | expect overworld     check what the game is doing
The save is continued (title, CONTINUE, quest-log recap skipped) before the
first step. A case passes when every expect holds; screenshots are for eyes.
"xfail": true marks a negative control, which passes only if a check fails.
"""

import argparse
import json
import os
import re
import struct
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from emu import Emu, GameReset, fresh_syms        # noqa: E402
from gamedata import REPO, const, item_name, map_info, mapsec, off   # noqa: E402
from savefile import Blocks, Mon                  # noqa: E402
from textwidth import load_charmap                # noqa: E402
import savedit                                    # noqa: E402

BUTTONS = {'A', 'B', 'START', 'SELECT', 'L', 'R'}
DIRS = {'UP', 'DOWN', 'LEFT', 'RIGHT'}


def live_blocks(e):
    return Blocks(e.read(e.ptr('gSaveBlock1Ptr'), off('sb1')), e.read(e.ptr('gSaveBlock2Ptr'), off('sb2')))


def live_mons(e):
    """The party (gPlayerParty, not the save's copy) and every PC box slot."""
    size = off('pokemon')
    party = bytearray(e.read(e.sym('gPlayerParty'), 6 * size))
    mons = [Mon(party, i * size) for i in range(e.u8(e.sym('gPlayerPartyCount')))]
    bsize = off('boxmon')
    n = const('TOTAL_BOXES_COUNT') * const('IN_BOX_COUNT')
    boxes = bytearray(e.read(e.ptr('gPokemonStoragePtr') + off('storage.boxes'), n * bsize))
    mons += [Mon(boxes, i * bsize) for i in range(n)]
    return [m for m in mons if m.has_species()]


def live_mons_where(e):
    """(where, Mon) for the party ('party') and the PC ('box')."""
    size = off('pokemon')
    party = bytearray(e.read(e.sym('gPlayerParty'), 6 * size))
    mons = [('party', Mon(party, i * size)) for i in range(e.u8(e.sym('gPlayerPartyCount')))]
    bsize = off('boxmon')
    n = const('TOTAL_BOXES_COUNT') * const('IN_BOX_COUNT')
    boxes = bytearray(e.read(e.ptr('gPokemonStoragePtr') + off('storage.boxes'), n * bsize))
    mons += [('box', Mon(boxes, i * bsize)) for i in range(n)]
    return [(w, m) for w, m in mons if m.has_species()]


def enemy_mons(e):
    size = off('pokemon')
    party = bytearray(e.read(e.sym('gEnemyParty'), 6 * size))
    return [m for m in (Mon(party, i * size) for i in range(6)) if m.has_species()]


_CHARS = None


def game_text(raw):
    global _CHARS
    if _CHARS is None:
        chars, _ = load_charmap()
        _CHARS = {}
        for c, bs in chars.items():
            if len(bs) == 1 and len(c) == 1:
                _CHARS.setdefault(bs[0], c)
    out = []
    for b in raw:
        if b == 0xFF:
            break
        out.append(_CHARS.get(b, '?'))
    return ''.join(out)


def mon_mismatches(e, where, m, keys):
    """The KEY=VALUE pairs of 'expect mon' that m doesn't match."""
    loc, lvl, ball, _ = m.met()
    bad = []
    for k, v in keys:
        if k == 'ot':
            got = game_text(m.ot_name_raw())
            ok = got == v
        elif k == 'otid':
            want = struct.unpack_from('<I', e.read(e.ptr('gSaveBlock2Ptr') + off('sb2.playerTrainerId'), 4))[0] \
                if v == 'player' else int(v, 0)
            got, ok = '%08x' % m.otid, m.otid == want
        elif k == 'metloc':
            got, ok = loc, loc == mapsec(v)
        elif k == 'metlvl':
            got, ok = lvl, lvl == int(v)
        elif k == 'ball':
            got, ok = ball, ball == const(item_name(v))
        elif k == 'snagged':
            got, ok = int(m.snagged()), int(m.snagged()) == int(v)
        elif k == 'item':
            got, ok = m.held(), m.held() == const(item_name(v))
        elif k == 'where':
            got, ok = where, where == v
        else:
            raise ValueError('unknown key %s' % k)
        if not ok:
            bad.append('%s=%s' % (k, got))
    return bad


_SYM_ADDRS = {}


def sym_addrs(rom, name):
    """Every address of NAME in the .sym: statics can share a name
    (HandleInputChooseAction is in four battle controllers)."""
    key = (rom, name)
    if key not in _SYM_ADDRS:
        found = set()
        with open(fresh_syms(rom)) as f:
            for line in f:
                p = line.split()
                if len(p) >= 4 and p[3] == name:
                    found.add(int(p[0], 16))
        _SYM_ADDRS[key] = found
    return _SYM_ADDRS[key]


def wait_action_menu(e, rom, presses=150):
    """Press B through battle text until a player battler's action menu (FIGHT/
    BAG/POKeMON/RUN) takes input. False if the battle ended first. (B never
    reaches the right battler's menu: pressed on the left one's, it does nothing.)"""
    want = sym_addrs(rom, 'HandleInputChooseAction')
    funcs = e.sym('gBattlerControllerFuncs')

    def menu_up():
        return any((e.u32(funcs + 4 * b) & ~1) in want for b in (0, 2))   # either player battler (doubles)

    for _ in range(120):            # the right battler's menu follows the left one's choice: no B for it
        if menu_up():
            e.run(20)
            return True
        e.run(1)
    for _ in range(presses):
        if not e.in_battle():
            return False
        if menu_up():
            e.run(20)
            return True
        e.press('B', hold=3, after=17)
    return False


def throw_ball(e, rom, item, side):
    """The 'throw' step; returns an error or None."""
    if not wait_action_menu(e, rom):
        return 'no action menu'
    blocks = live_blocks(e)
    want = const(item_name(item))
    index = None
    n = 0
    for o in blocks._slots(item):
        iid = struct.unpack_from('<H', blocks.sb1, o)[0]
        if iid == want:
            index = n
            break
        if iid:
            n += 1
    if index is None:
        return 'no %s in the bag' % item
    for key in ('UP', 'LEFT', 'RIGHT', 'A'):      # the action cursor to BAG
        e.press(key, hold=3, after=12)
    bag = e.sym('CB2_BagMenuRun')
    for _ in range(300):
        if (e.callback2() & ~1) == bag:
            break
        e.run(1)
    else:
        return 'the bag never opened'
    e.run(40)
    state = e.sym('gBagMenuState')
    pocket = e.u16(state + 6)                     # 0 ITEMS, 1 KEY ITEMS, 2 POKe BALLS
    balls = const('POCKET_POKE_BALLS') - 1
    for _ in range(abs(balls - pocket)):
        e.press('RIGHT' if balls > pocket else 'LEFT', hold=3, after=30)
    if e.u16(state + 6) != balls:
        return 'could not reach the POKe BALLS pocket'
    at = e.u16(state + 8 + 2 * balls) + e.u16(state + 14 + 2 * balls)    # itemsAbove + cursorPos
    for _ in range(abs(index - at)):
        e.press('DOWN' if index > at else 'UP', hold=3, after=10)
    e.press('A', hold=3, after=30)                # the item, then USE
    e.press('A', hold=3, after=30)
    if side:                                      # the target cursor (trainer doubles)
        cursor = sym_addrs(rom, 'HandleInputChooseBallTarget')
        funcs = e.sym('gBattlerControllerFuncs')
        for _ in range(300):
            if any((e.u32(funcs + 4 * b) & ~1) in cursor for b in (0, 2)):
                break
            e.run(1)
        else:
            return 'no BALL target cursor'
        e.run(10)
        want = 1 if side == 'L' else 3            # B_POSITION_OPPONENT_LEFT / _RIGHT
        if e.u8(e.sym('gMultiUsePlayerCursor')) != want:
            e.press('RIGHT', hold=3, after=12)
        e.press('A', hold=3, after=12)
    return None


def fight(e, rom, n):
    """The 'fight' step; returns an error or None."""
    if not wait_action_menu(e, rom):
        return 'no action menu'
    for key in ('UP', 'LEFT', 'A'):               # FIGHT
        e.press(key, hold=3, after=12)
    e.run(20)
    for key in ('UP', 'LEFT'):                    # the move cursor to the first move
        e.press(key, hold=3, after=10)
    i = n - 1
    if i & 1:
        e.press('RIGHT', hold=3, after=10)
    if i & 2:
        e.press('DOWN', hold=3, after=10)
    e.press('A', hold=3, after=20)
    if e.u32(e.sym('gBattleTypeFlags')) & BATTLE_TYPE_DOUBLE:
        e.press('A', hold=3, after=20)
    return None


def run_away(e, rom):
    """The 'run' step: RUN from the action menu; returns an error or None."""
    if not wait_action_menu(e, rom):
        return 'no action menu'
    for key in ('DOWN', 'RIGHT', 'A'):            # RUN, bottom right
        e.press(key, hold=3, after=12)
    return None


BATTLE_TYPE_DOUBLE = 1                            # include/constants/battle.h


def run_special(e, name, wait):
    """Start a four-command script that calls special NAME. The script lives in
    the global script context's own data[] words, which nothing a special does
    touches, so it survives a battle the special starts."""
    fn = e.sym(name) | 1
    table, end = e.sym('gSpecials'), e.sym('gSpecialsEnd')
    ids = [i for i in range((end - table) // 4) if e.u32(table + 4 * i) == fn]
    if not ids:
        return 'no special %s' % name
    for _ in range(60):                           # continuing, the map's scripts may still run
        if e.field_idle():
            break
        e.run(10)
    else:
        return 'the overworld is not idle'
    ctx = e.sym('sGlobalScriptContext')
    code = bytes([0x25]) + struct.pack('<H', ids[0]) + (b'\x27' if wait else b'') + b'\x6b\x02'
    data = ctx + 100                              # struct ScriptContext data[4]
    e.write(data, code.ljust(16, b'\0'))
    e.write(ctx, struct.pack('<BBBxII', 0, 1, 0, 0, data))   # stackDepth, mode BYTECODE, nativePtr, scriptPtr
    e.write(ctx + 92, struct.pack('<II', e.sym('gScriptCmdTable'), e.sym('gScriptCmdTableEnd')))
    e.write(e.sym('sGlobalScriptContextStatus'), b'\0')     # CONTEXT_RUNNING
    return None


def species_id(name):
    return const(name if name.startswith('SPECIES_') or name.isdigit() else 'SPECIES_' + name)


_CHARS = None


def decode_text(raw):
    """Game text to a str, single characters only (placeholders dropped)."""
    global _CHARS
    if _CHARS is None:
        _CHARS = {}
        with open(os.path.join(REPO, 'charmap.txt'), encoding='utf-8') as f:
            for line in f:
                q = line.split('=')
                if len(q) == 2 and len(q[0].strip()) == 3 and q[0].strip()[0] == "'":
                    code = q[1].split('@')[0].strip()
                    if len(code) == 2:
                        _CHARS.setdefault(int(code, 16), q[0].strip()[1])
    out = []
    i = 0
    while i < len(raw) and raw[i] != 0xFF:
        b = raw[i]
        if b in (0xFA, 0xFB, 0xFE):         # line breaks and the paragraph
            out.append(' ')
        elif b == 0xFD or b == 0xFC:        # placeholder / control code + arg
            i += 1
        elif b in _CHARS:
            out.append(_CHARS[b])
        i += 1
    return ''.join(out)


def rom_text_prefix(e, label):
    """The first bytes of the text at LABEL, up to its first placeholder or
    control code (those differ once expanded into gStringVar4)."""
    raw = e.read(e.sym(label), 96)
    out = bytearray()
    for b in raw:
        # line breaks stay as they are in gStringVar4; placeholders, control
        # codes and the end don't
        if b >= 0xF7 and b not in (0xFA, 0xFB, 0xFE):
            break
        out.append(b)
    if len(out) < 4:
        raise ValueError('text %s starts with too little plain text to watch' % label)
    return bytes(out[:90])


def rom_text_run(e, label):
    """The longest stretch of plain text in the first bytes at LABEL, for texts
    that start with a placeholder (battle texts: "{B_ATK_NAME} is loafing")."""
    raw = e.read(e.sym(label), 64)
    best, cur = b'', bytearray()
    for b in raw:
        if b >= 0xF7:
            if len(cur) > len(best):
                best = bytes(cur)
            cur = bytearray()
            if b == 0xFF:
                break
        else:
            cur.append(b)
    if len(best) < 4:
        raise ValueError('text %s has too little plain text to watch' % label)
    return best[:32]


def run_case(case, rom, shots, presses_log=None):
    name = case['name']
    base = case.get('base', 'saves/hoenn.sav')
    base = base if os.path.isabs(base) else os.path.join(REPO, base)
    fails = []
    with tempfile.TemporaryDirectory() as tmp:
        sav = os.path.join(tmp, 'case.sav')
        argv = [base, '-o', sav]
        for line in case.get('edit', []):
            argv += line.split()
        with open(os.devnull, 'w') as quiet:
            old, sys.stdout = sys.stdout, quiet
            try:
                rc = savedit.run(argv)
            finally:
                sys.stdout = old
        if rc:
            return False, ['savedit failed: %s' % ' '.join(argv[3:])]
        with Emu(rom, sav) as e:
            def on_menu(emu):
                for line in case.get('menu', []):
                    q = line.split()
                    assert q[0] == 'poke', line
                    emu.write(emu.sym(q[1]), bytes([int(q[2], 0)]))
            try:
                e.boot_continue(on_menu=on_menu, leave_menu_only=case.get('leave_menu_only', False))
            except (TimeoutError, GameReset) as ex:
                return False, ['could not continue: %s' % ex]
            watches = {}            # label -> [prefix, seen]
            last_presses = [0]

            def look():
                if watches:
                    shown = e.read(e.sym('gStringVar4'), 96)
                    battle = e.read(e.sym('gDisplayedStringBattle'), 64)
                    for w in watches.values():
                        if shown.startswith(w[0]) or (w[2] and (w[0] in shown or w[0] in battle)):
                            w[1] = True

            def press(key, after):
                e.press(key, hold=3, after=after)
                look()

            for step in case.get('steps', []):
                p = step.split()
                head = p[0].upper()
                if head.split('*')[0] in BUTTONS:
                    key, _, times = head.partition('*')
                    for _ in range(int(times or 1)):
                        press(key, 20)
                elif head in DIRS:
                    e.walk(head, int(p[1]) if len(p) > 1 else 1)
                elif head == 'WAIT':
                    e.run(int(p[1]))
                elif head == 'WATCH':
                    try:
                        watches[p[1]] = [rom_text_prefix(e, p[1]), False, False]
                    except ValueError:      # starts with a placeholder: look for its plain part anywhere
                        watches[p[1]] = [rom_text_run(e, p[1]), False, True]
                    look()
                elif head == 'MASHTEXT':
                    want = rom_text_prefix(e, p[1])
                    last_presses[0] = 0
                    for _ in range(int(p[2]) if len(p) > 2 else 300):
                        if e.read(e.sym('gStringVar4'), 96).startswith(want):
                            break
                        press('A', 20)
                        last_presses[0] += 1
                    else:
                        fails.append('%s: never shown' % step)
                elif head == 'MASH':
                    last_presses[0] = 0
                    for _ in range(int(p[1]) if len(p) > 1 else 300):
                        if e.field_idle():
                            e.run(20)
                            if e.field_idle():
                                break
                        press('A', 20)
                        last_presses[0] += 1
                    else:
                        fails.append('%s: the game never went idle' % step)
                elif head == 'ENCOUNTER':
                    for i in range(int(p[1]) if len(p) > 1 else 200):
                        if not e.in_overworld():
                            break
                        e.walk('LEFT' if i % 2 == 0 else 'RIGHT')
                    for _ in range(40):     # the battle transition
                        if e.in_battle():
                            break
                        e.run(15)
                    if not e.in_battle():
                        fails.append('%s: no wild battle started' % step)
                elif head == 'EVOMASH':
                    evo = {e.syms.get('CB2_EvolutionSceneUpdate'), e.syms.get('CB2_TradeEvolutionSceneUpdate')}
                    seen = False
                    for _ in range(int(p[1]) if len(p) > 1 else 200):
                        inside = (e.callback2() & ~1) in evo
                        if seen and not inside:
                            break
                        seen = seen or inside
                        e.press('A', hold=3, after=37)
                    else:
                        fails.append('%s: %s' % (step, 'the evolution never ended' if seen else 'no evolution scene'))
                elif head == 'MASHTO':
                    want = e.sym(p[1])
                    last_presses[0] = 0
                    for _ in range(int(p[2]) if len(p) > 2 else 60):
                        if (e.callback2() & ~1) == want:
                            break
                        press('A', 27)
                        last_presses[0] += 1
                    else:
                        fails.append('%s: never got there' % step)
                elif head == 'WAITCB2':
                    want = e.sym(p[1])
                    for _ in range(int(p[2]) if len(p) > 2 else 3000):
                        if (e.callback2() & ~1) == want:
                            break
                        e.run(1)
                    else:
                        fails.append('%s: never got there' % step)
                elif head == 'MASHBATTLE':
                    for _ in range(int(p[1]) if len(p) > 1 else 100):
                        if e.in_battle():
                            break
                        e.press('A', hold=3, after=20)
                    else:
                        fails.append('%s: no battle started' % step)
                elif head == 'THROW':
                    err = throw_ball(e, rom, p[1], p[2].upper() if len(p) > 2 else None)
                    if err:
                        fails.append('%s: %s' % (step, err))
                elif head == 'SPECIAL':
                    err = run_special(e, p[1], len(p) > 2 and p[2].lower() == 'wait')
                    if err:
                        fails.append('%s: %s' % (step, err))
                    e.run(2)
                elif head == 'RUN':
                    err = run_away(e, rom)
                    if err:
                        fails.append('%s: %s' % (step, err))
                elif head == 'FIGHT':
                    err = fight(e, rom, int(p[1]))
                    if err:
                        fails.append('%s: %s' % (step, err))
                elif head == 'SHOT':
                    if shots:
                        e.shot(os.path.join(shots, '%s_%s.png' % (name, p[1])))
                elif head == 'EXPECT':
                    what = p[1]
                    if what == 'saw':
                        got = int(watches[p[2]][1]) if p[2] in watches else None
                        if got != int(p[4]):
                            fails.append('%s: saw %s' % (step, got))
                    elif what == 'text':
                        shown = decode_text(e.read(e.sym('gStringVar4'), 400))
                        if ' '.join(p[2:]) not in shown:
                            fails.append('%s: the message is %r' % (step, shown))
                    elif what == 'song':
                        header, status = struct.unpack('<II', e.read(e.sym('gMPlayInfo_BGM'), 8))
                        if header != e.sym(p[2]) or not status & 0xFFFF:
                            fails.append('%s: BGM header %08x, status %08x' % (step, header, status))
                    elif what == 'presses':
                        if presses_log is not None:
                            presses_log.append(last_presses[0])
                        if not last_presses[0] <= int(p[3]):
                            fails.append('%s: took %d' % (step, last_presses[0]))
                    elif what in ('flag', 'var', 'trainer'):
                        blocks = live_blocks(e)
                        want = int(p[4], 0)
                        got = {'flag': lambda n: int(blocks.flag(n)), 'var': blocks.var,
                               'trainer': lambda n: int(blocks.trainer_beaten(n))}[what](p[2])
                        if got != want:
                            fails.append('%s: %s %s is %d, expected %d' % (step, what, p[2], got, want))
                    elif what == 'money':
                        got, want = live_blocks(e).money(), int(p[3], 0)
                        if got != want:
                            fails.append('%s: money is %d' % (step, got))
                    elif what == 'mon' and p[3:4] == ['=']:
                        sp = species_id(p[2])
                        got, want = sum(1 for m in live_mons(e) if m.species() == sp and not m.is_egg()), int(p[4], 0)
                        if got != want:
                            fails.append('%s: mon %s is %d' % (step, p[2], got))
                    elif what == 'mon':
                        sp = [species_id(n) for n in p[2].split('|')]
                        keys = [kv.split('=', 1) for kv in p[3:]]
                        cands = [(w, m) for w, m in live_mons_where(e) if m.species() in sp and not m.is_egg()]
                        misses = [mon_mismatches(e, w, m, keys) for w, m in cands]
                        if not cands:
                            fails.append('%s: no %s' % (step, p[2]))
                        elif all(misses):
                            fails.append('%s: closest has %s' % (step, ' '.join(min(misses, key=len))))
                    elif what == 'dex':
                        state = live_blocks(e).dex_state(savedit._national(species_id(p[2])))
                        want = {'none': (False,) * 4, 'seen': (False, True, True, True),
                                'caught': (True,) * 4}[p[4]]
                        if state != want:
                            fails.append('%s: owned/seen/seen1/seen2 = %s' % (step, ''.join('01'[b] for b in state)))
                    elif what in ('enemy', 'enemycount'):
                        mons = enemy_mons(e)
                        if what == 'enemy':
                            got, want = sum(1 for m in mons if m.species() == species_id(p[2])), int(p[4], 0)
                        else:
                            got, want = len(mons), int(p[3], 0)
                        if got != want:
                            fails.append('%s: got %d' % (step, got))
                    elif what == 'double':
                        got = int(bool(e.u32(e.sym('gBattleTypeFlags')) & BATTLE_TYPE_DOUBLE))
                        if got != int(p[3]):
                            fails.append('%s: got %d' % (step, got))
                    elif what in ('item', 'egg', 'fateful', 'mons', 'count'):
                        want = int(p[4], 0)
                        if what == 'item':
                            got = live_blocks(e).item_count(p[2])
                        elif what in ('mons', 'count'):
                            sp = species_id(p[2])
                            got = sum(1 for m in live_mons(e) if m.species() == sp and not m.is_egg())
                        else:
                            sp = species_id(p[2])
                            mons = [m for m in live_mons(e) if m.species() == sp]
                            got = sum(1 for m in mons if (m.is_egg() if what == 'egg' else m.fateful()))
                        if got != want:
                            fails.append('%s: %s %s is %d' % (step, what, p[2], got))
                    elif what == 'species':
                        slot = int(p[2])
                        want = [species_id(n) for n in p[3].split('|')]
                        size = off('pokemon')
                        got = Mon(bytearray(e.read(e.sym('gPlayerParty') + slot * size, size)), 0).species()
                        if got not in want:
                            fails.append('%s: party slot %d is species %d' % (step, slot, got))
                    elif what == 'sym':
                        got, want = e.u8(e.sym(p[2])), int(p[4], 0)
                        if got != want:
                            fails.append('%s: %s is %d' % (step, p[2], got))
                    elif what == 'deref':
                        base = e.ptr(p[2])
                        got, want = (e.u16(base + int(p[3], 0)) if base else None), int(p[5], 0)
                        if got != want:
                            fails.append('%s: got %s' % (step, got))
                    elif what == 'hp':
                        base = e.sym('gPlayerParty') + int(p[2]) * off('pokemon')
                        hp, maxhp = e.u16(base + 86), e.u16(base + 88)
                        if hp != (maxhp if p[4] == 'full' else int(p[4], 0)):
                            fails.append('%s: HP %d/%d' % (step, hp, maxhp))
                    elif what == 'move':
                        size = off('pokemon')
                        mon = Mon(bytearray(e.read(e.sym('gPlayerParty') + int(p[2]) * size, size)), 0)
                        moves = struct.unpack_from('<4H', mon.subs()['A'], 0)
                        if const(p[3] if p[3].startswith('MOVE_') else 'MOVE_' + p[3]) not in moves:
                            fails.append('%s: party slot %s knows %s' % (step, p[2], list(moves)))
                    elif what == 'cb2':
                        if (e.callback2() & ~1) != e.sym(p[2]):
                            fails.append('%s: callback2 is %08x' % (step, e.callback2()))
                    elif what == 'map':
                        m = map_info(p[2])
                        g, n, _, _ = e.location()
                        if (g, n) != (m['group'], m['num']):
                            fails.append('%s: on map %d.%d' % (step, g, n))
                    elif what == 'battle' and not e.in_battle():
                        fails.append('%s: not in a battle' % step)
                    elif what == 'overworld' and not e.in_overworld():
                        fails.append('%s: not in the overworld' % step)
                else:
                    fails.append('unknown step %r' % step)
                if e.reset_seen():
                    fails.append('game reset during %r' % step)
                    break
    return not fails, fails


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('cases', help='JSON-lines file of cases')
    ap.add_argument('--rom', default=os.path.join(REPO, 'pokemonthyl.gba'))
    ap.add_argument('--shots', help='directory for the cases\' screenshots')
    ap.add_argument('--only', help='run only the case with this name')
    a = ap.parse_args()
    if a.shots:
        os.makedirs(a.shots, exist_ok=True)
    total = passed = 0
    with open(a.cases) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            case = json.loads(line)
            if a.only and case['name'] != a.only:
                continue
            total += 1
            presses = []
            ok, fails = run_case(case, a.rom, a.shots, presses)
            if case.get('xfail'):
                # a negative control: it must fail, or the checks prove nothing
                ok, fails = (not ok), (['expected to fail but passed'] if ok else [])
            passed += ok
            print('%-4s %s%s%s' % ('ok' if ok else 'FAIL', case['name'],
                                   ''.join(' (A x%d)' % n for n in presses),
                                   ''.join('\n     ' + x for x in fails)),
                  flush=True)
    print('%d/%d cases passed' % (passed, total))
    return 0 if passed == total else 1


if __name__ == '__main__':
    sys.exit(main())
