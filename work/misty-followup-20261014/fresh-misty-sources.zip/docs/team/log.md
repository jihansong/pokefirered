# 팀 로그

Thunder Yellow 개발 팀의 역할, 진행 방식, 결정 기록. 에이전트는 매번 새로 시작하므로 **이 문서가 팀의 기억**이다. 역할별 지침은 `.claude/agents/*.md`에 있다.

## 역할 (2026-09-23 사용자 승인)

| 역할 | 누구 | 맡는 일 |
|---|---|---|
| 총괄 프로듀서 | 메인 세션 | 작업 분배, 우선순위, 결과 검토, 커밋·릴리스, 사용자 보고. 외부로 나가는 작업(push·릴리스)은 사용자 확인 뒤에만 |
| 기획 | `planner` | 스토리·이벤트, 1~3세대 원작과 애니메이션 각색, 스타팅 방식, 밸런스(레벨·상금·경험치·보상), 단계 계획서 |
| 디자이너 | `designer` | 맵·레이아웃, UI, 팔레트, 정지 그림, 애니메이터용 그림 사양 |
| 애니메이터 | `animator` | 오프닝·엔딩 크레딧 등 연출: 콘티, 장면별 프레임, 그림, 장면 코드 |
| 엔지니어 | `engineer` | 코더+개발자. C·스크립트·트레이너, 빌드·도구·세이브 호환·릴리스 빌드. 일이 커지면 둘로 나눈다 |
| QA | `qa` | 매 단계 끝과 릴리스 전 점검. 안정성 검사 전부 + 에뮬레이터 플레이 + 재미·난이도·차별성 판단. PASS/FAIL로 단계를 막는다 |
| 일러스트레이터 | `illustrator` | 정지 일러스트(인물·트레이너·전투 그림, 오프닝·엔딩 키 아트, 장면 스틸) + 애니메이터·게임 전체 그림체 점검. 애니메이션 이펙트는 애니메이터, 맵·타일·UI는 디자이너 |
| 예술감독 | `art-director` | 모든 시각물(애니·일러스트·맵·UI·연출)을 포켓몬 시리즈의 철학·미학에 비추어 픽셀 단위까지 검토·승인. **APPROVED 전에는 그림이 출시되지 않고, 사용자 시안도 예술감독 승인 뒤에 보인다** |
| 음악 감독 | `music-director` | 썬더옐로우 오리지널 사운드트랙 방향·큐 시트(다른 버전에 없는 이벤트·캐릭터 조우·새 마을·이벤트 장소·엔딩 크레딧). 아래 세 명을 지휘 |
| 음악 리서처 | `music-researcher` | 시리즈 음악 특성·기존 곡 분석, 큐가 필요한 곳, 엔진 제약, 닮으면 안 되는 참조 목록 |
| 음악 작업자 | `music-composer` | 오리지널 MIDI 작곡(재생성 가능한 생성기), midi.cfg·곡 표·상수·맵/스크립트 연결 |
| 음악 검수자 | `music-reviewer` | 기술(m4a·루프·음량·길이)·스타일·**독창성(기존 선율 차용 금지)** 검사, 들을 수 있는 미리 듣기 파일 제작 |

## 진행 방식

1. 기획이 계획서를 쓴다 → 프로듀서 검토 → **사용자 승인**
2. 디자이너·애니메이터·엔지니어가 나눠 만든다(겹치지 않으면 동시에)
3. QA가 점검하고 보고서를 `docs/team/qa/`에 남긴다. 그림·연출이 있으면 예술감독이 `docs/team/art/`에, 음악이 있으면 음악 검수자가 `docs/music/review/`에 따로 판정한다. 셋 중 하나라도 통과하지 못하면 해당 역할로 되돌린다
4. 프로듀서가 최종 확인하고 커밋, 사용자에게 보고. 릴리스·push는 사용자 확인 뒤

- 에이전트는 커밋하지 않는다. 커밋은 프로듀서만(워크트리 브랜치 커밋은 프로듀서가 허락한 작업에 한해, 프로듀서가 검토 뒤 가져온다).
- **인력 운용(2026-09-26 사용자)**: 노는 역할이 없게 하되 불필요한 토큰은 쓰지 않는다. "다음에 꼭 필요한 일"이 있는 역할만 배정하고, 없으면 다음 계기(선행 작업 완료)까지 대기. 우선순위: 효율·효과·재미·예술성·기획 의도 적합도
- 비용 때문에 기본은 단계마다 필요한 역할만, 한두 명씩 부른다.
- 애니메이션 핵심 장면은 중간 시안을 사용자에게 보여 주고 승인받는다.

## 결정 기록

| 날짜 | 결정 | 근거 |
|---|---|---|
| 2026-09-23 | 역할 6개 체제(코더·개발자는 엔지니어 하나로 시작) | 사용자가 추천안 승인 |
| 2026-09-23 | QA 도구는 `tools/qa/`, 환경은 `.devcontainer/setup.sh`, 문서는 `docs/INSTALL.md` | 컨테이너 재생성으로 `/root`의 도구가 사라짐 |
| 2026-09-23 | 오프닝·엔딩은 애니메이션 프레임을 베끼지 않고, 원작 장면의 내용을 FR/LG 화풍 픽셀 아트로 새로 그린다. 길이는 원래 장면에 맞춘다 | 사용자 요청 + 저작물 복제 불가 |
| 2026-09-24 | 마스터 플랜 결정 8개 **전부 추천안**: Q1 성도 축약 본토(약 95맵) · Q2 호연 먼저 · Q3 로켓단 등장=반드시 전투(1·12번 추가, 상아호 대체 등장) · Q4 나옹의 동전 보너스 · Q5 뮤의 알(트럭 뮤와 택일)+이브이 알 · Q6 스타팅 안 1(박사 1+이벤트 2, §5.9 Q5 변경) · Q7 엔딩 혼합 · Q8 레벨 곡선 압축 | 사용자 "all as recommended" |
| 2026-09-24 | 오프닝 질문 5개 **전부 추천안**: 7장면 · 주인공 레드 고정 · 칠색조 실루엣으로 2세대 예고 · 피카츄는 게임 기본 울음 · 타이틀 화면 피카츄로 마무리(따로 달려오는 컷 없음) | 사용자 "오프닝 질문도 전부 추천대로" |
| 2026-09-26 | 사용자 플레이 보고 반영: 버그 (1) 칸토 포켓몬 진화 멈춤 (1-2) 피카츄 진화 제한 범위 (2) 포켓워치 시각 표시 없음 → **v0.9.0 전에 수정**. 요청 (3) 달맞이산 화석 둘 다 (4) 4번도로 메가톤펀치·킥 둘 다 (5) 양자택일 이벤트는 예외 없이 전부 얻게(일반 원칙) (6) 트레이너전 스내그 (7) `saves/pokemonthyl_hoenn_QAed.sav` 회귀 세이브 추가 → 릴리스 배치안 승인 후 | 사용자 |
| 2026-09-26 | 스타터: 9/24 승인 그대로(오달박사 아차모 + 이벤트 2). **셀리오 선물과 중복돼도 무방**(플래그 공유 안 함) | 사용자 결정 1 |
| 2026-09-26 | 스내그 예외: 트레이너 팀의 전설(N·토너먼트 포함)과 로사·로이의 나옹은 잡을 수 없다(볼이 튕기고 짧은 거부 메시지). 관장·라이벌 포함 그 외 전부 허용 | 사용자 결정 2 |
| 2026-09-26 | 스내그 후 재대결: 일반 트레이너는 같은 팀 그대로. 라이벌·로사·로이는 빼앗긴 포켓몬이 이후 전투에서 빠지게(작업량이 크면 별도 항목으로 제안) | 사용자 결정 3 |
| 2026-09-26 | `pokemonthyl_hoenn_QAed.sav` 기준 롬 = v0.8.0 | 사용자 결정 4 |
| 2026-09-26 | v0.9.0 QA 검증은 버그 수정 뒤에 한 번 | 사용자 결정 5 |
| 2026-09-26 | 배치: (3) 달맞이산 화석 둘 다 · (4) 4번도로 튜터(대사 수정 + **한 포켓몬 제한 해제**) · (5) 양자택일 4건(격투도장·달맞이산·STERN 심해 도구·트릭하우스 상품) 전부 지급 · (7) `pokemonthyl_hoenn_QAed.sav`(기준 v0.8.0) 세이브 검사 상시 포함 → **v0.9.0**. (6) 스내그 → **v0.10.0 단독 릴리스**(라이벌·로사·로이의 빼앗긴 포켓몬 제외 포함). 호연 Z3·오프닝은 **v0.11.0**, 이후 한 칸씩 뒤로 | 사용자 "배치안대로 진행해, 튜터 제한도 풀어줘" |
| 2026-09-26 | 양자택일 원칙: 기술·아이템·포켓몬 양자택일 이벤트는 예외 없이 전부 얻게 한다. 앞으로 여는 구역에도 적용(한 플레이 한 번 전설 규칙 Q4·뮤 하나는 별개) | 사용자 요청 (5) |
| 2026-09-26 | v0.10.0 스내그 계획 결정 13개 **전부 추천안**(전부 잡으면 상금 전액 · 도감/별명 화면 생략 · 전설·나옹에 던지면 볼 반환+턴 소모 · 개체값 유지 · 지닌 물건 함께 · 이름 규칙 단순안 · 교환 경험치 없음 · 요약 문구 유지 · 호연 장소 "교환" 표시 버그 수정 · 칸토 라이벌 19전·토너먼트 BLUE·로켓 14전만 기록 · 라이벌 에이스 유지 · 반복 제한 없음 · 상록 힌트 1줄) | 사용자 "두 계획 다 추천대로" |
| 2026-09-26 | v0.11.0 호연 Z3 계획 결정 8개 **전부 추천안**(Petalburg Woods 로켓단 1전 · ROXANNE 4마리 · WALLY 포획 시범은 튜토리얼 전투 재사용 · BRINEY 배는 목적지 선택 후 워프 · 라이벌 103번 도로 1전(성별 반대) · 스타터 등장은 새 그림 없이 · 오프닝 승인이 늦으면 v0.11.1 단독 · 털보박사 도감 보상 40/80/120/160/200) | 사용자 "두 계획 다 추천대로" |
| 2026-09-26 | 스내그 결정 2 수정: **트레이너 팀의 전설도 스내그 가능**(보통 확률). 야생 전설은 지금처럼 보통 확률로 포획. 거부는 로사·로이의 나옹만. 스내그한 전설은 "한 플레이 한 번" 규칙의 예외 | 사용자 답변(범위: 트레이너+야생 전설 전부, 포획률: 보통) |
| 2026-09-26 | 역할 추가: 일러스트레이터·예술감독·음악 감독(+리서처·작업자·검수자). 디자이너는 맵·타일·UI로 좁힘 | 사용자 지시 |
| 2026-09-26 | **음악 범위 제한**: 오리지널 곡은 기존 FRLG·에메랄드 곡 중 어울리는 게 정말 없는 장면(신규 이벤트·타이틀·엔딩 크레딧 등)에만. 나머지는 기존 곡 배정. 리서처 결과를 "새 곡 필요" / "기존 곡으로 충분" 두 목록으로 사용자에게 보고 → **사용자가 승인한 장면만 작곡**. 작곡한 곡은 반드시 WAV 미리 듣기를 만들고, **사용자 승인 전에는 게임에 넣지 않는다** | 사용자 조정 2 |
| 2026-09-26 | 예술감독·음악 검수자 게이트는 유지. 게이트 때문에 릴리스 일정이 늦어지면 그 사실을 사용자에게 보고 | 사용자 조정 3 |
| 2026-09-26 | **오프닝·엔딩 크레딧은 제대로 된 애니메이션**으로: 공식 1·2·3세대(적/녹/황, 금/은/크리스탈, 루비/사파이어/에메랄드, FR/LG) 오프닝·엔딩 수준 — 스크롤 배경, 여러 인물·포켓몬의 연속 동작, 카메라 이동, 이펙트. 정지 일러스트를 넘기는 방식 금지. 마스터 플랜 Q7 "혼합(일러스트 5~6장 + 맵 연기)"을 이것으로 **대체**. 예술감독 판정 기준에 포함 | 사용자 지시 |
| 2026-09-26 | 엔딩 크레딧 스태프 명단 맨 끝(총괄 디렉터 다음)에 **Joseph Song** 추가 | 사용자 지시 |
| 2026-09-26 | **오프닝·엔딩 크레딧의 길이와 퀄리티 하한 = 공식 1·2·3세대 수준.** 그 이상은 허용, 그 이하는 불가. 길이: 오프닝은 교체 구간(752프레임, 12.5초) 이상·전원→타이틀 24.3초 이상, 엔딩은 각각 250.6초(14,970프레임, `MUS_CREDITS` 전체·에필로그 포함) 이상 — 2026-09-26 사용자가 174초 표기를 이것으로 통일. 품질: 공식 오프닝·엔딩과 같은 연속 애니메이션 밀도 이상. 예술감독 판정의 불합격 기준 | 사용자 지시 |
| 2026-09-26 | **엔딩 길이 기준 통일: 세 엔딩 모두 250.6초(14,970프레임, 크레딧 곡 `MUS_CREDITS` 전체, 에필로그 포함).** 174초(스크립트 합계) 표기는 폐기 | 사용자 지시 |
| 2026-09-26 | **오프닝 방향 전환(사용자: 코드로 새로 그린 시안은 공식 FR/LG에 크게 미달).** (B) 새로 그리지 않고 **저장소에 있는 공식 품질 픽셀 아트**(FR/LG·에메랄드의 전투 스프라이트·트레이너 그림·인트로/크레딧 배경·에메랄드 오프닝 자원 등)로 애니 1기 이야기를 재구성, 코드는 연출(카메라·동작·이펙트·타이밍)만. 엔딩 3종도 같은 방식. 코드로 그린 새 그림(장면 2·4·5·6 시안)은 쓰지 않는다 | 사용자 "B로 하고" |
| 2026-09-26 | **오프닝 길이: FR/LG처럼 10초 안팎**(길이를 줄이고 품질에 집중). 앞선 "교체 구간 752프레임 이상" 하한은 이것으로 대체. 품질 하한(공식 FR/LG 이상)은 유지 | 사용자 |
| 2026-09-26 | 예술감독 판정 방식: **공식 프레임과 나란히 비교**해 판정(이전 시안 대비가 아니라). 새 그림이 사용자에게 가기 전 공식 원판과 직접 비교 필수 | 프로듀서(실패 원인 교정) |
| 2026-09-26 | **성도 타당성 검토 승인(착수 승인 아님, 전제 조건 승인).** 새 타일 방식: 공식 타일(FR/LG·에메랄드) 최대 재활용 + 재활용 불가능한 랜드마크만 에이전트 신규 제작, **예술감독의 공식 타일 나란히 비교 게이트 필수**. 호연 Z4~Z7 진행 중 여유가 있을 때: 32MB 롬 검증, 필드 스프라이트 ID 재사용 프로토타입, 타일 파이프라인 프로토타입 + 파일럿 맵 2개(연두마을, 29번 도로)를 만들어 사용자에게 보인다. 성도 본 작업 착수는 호연 완료 후 파일럿 맵을 보고 사용자가 결정 | 사용자 |
| 2026-09-26 | **에메랄드 소스 규칙 정정**: `/root/src/pokeemerald`는 호연 콘텐츠(맵·타일·스프라이트·음악·이벤트 구조)의 출처로 계속 쓴다(이미 이식된 호연과 같은 공식 게임 데이터). 금지는 외부 일러스트·애니 프레임·웹 이미지뿐이고, 이 금지는 오프닝·엔딩·타이틀 같은 신규 연출물에 적용. v0.11.0의 에메랄드 곡 이식과 누락된 스토리 캐릭터 복원은 pokeemerald에서 | 사용자 |
| 2026-09-26 | 타이틀 개편 진행: 정지 일러스트 초안 → 예술감독 검토. **3회 돌려도 기준 미달이면 중단하고 대안**(피카츄 전투 정면 스프라이트 기반 + 단색조 처리 + 전기 이펙트). 두 안 모두 PNG로 사용자에게. 참고 자료는 저장소 루트 `reference/`(gitignore) | 사용자 |
| 2026-09-26 | **오프닝 장면 2 승인.** 이 피카츄(팔 내림, 2배 클로즈업 포함)를 오프닝·엔딩 전체의 기준 모델로 확정. 다음: 뒷모습·옆모습·점프 모델 시트 → 일러스트레이터·예술감독 확인 → 장면 4·5 | 사용자 |
| 2026-09-26 | 음악 답: 정한 범위대로(새 곡은 기존 곡이 정말 안 맞는 곳만, 승인한 장면만 작곡, WAV 미리 듣기, 승인 전 게임에 넣지 않음). 리서처 질문 대응: Q2 오프닝·타이틀 기존 곡 유지 · Q3 파도타기 피카츄→MUS_POKE_JUMP · Q5 은빛산 정상 조우 무음+전투 MUS_VS_CHAMPION · Q6 기존 곡 교체 5건 = "기존 곡 배정"으로 승인 · Q4 **호연 Z3용 에메랄드 곡(라이벌 조우·아쿠아단 등)은 이식으로 3단계 작업에 포함** · Q1 성도 엔딩 새 곡은 **아직 승인 안 됨**(성도 착수 때 다시) | 사용자 |
| 2026-09-26 | 성도: **호연이 끝나기 전에는 구현에 착수하지 않는다**(선행 단계 G0~G2 병행도 하지 않음 — 타당성 검토 Q6의 (a) 대신 "착수 안 함"). 지금은 `docs/johto-feasibility.md` 검토만, 사용자 승인 뒤 일정에 넣는다. 검토의 다른 질문(Q1~Q5·Q7·Q8)은 승인 때 함께 | 사용자 |
| 2026-09-27 | **v0.10.0 릴리스**(스내그). 푸시 전 이브이 알 메모를 "JESSIE & JAMES에게서 받은 알"로 수정(`48e75f4d1`), 세이브 6종 IDENTICAL 재확인 후 master·태그 푸시, GitHub 릴리스(BPS + 공략집 v0.10.0 docx) | 사용자 "v0.10.0 릴리스 승인" |
| 2026-09-27 | **오프닝 방향 (a) 피카츄 vs 라이츄**: 리프그린 오프닝(팬텀 vs 니드리노) 구조, 게임 안 공식 스프라이트만. 애니 클립은 기술 흐름(대치 → 고속 돌진 교환 → 10만볼트 충돌 → 피카츄가 민첩성으로 승부)과 컷 리듬만 참고, 프레임 복사 금지. 승인 소스: 마티스 트레이너 그림, 갈색시티 체육관 배경, 전광석화·10만볼트·번개 배틀 애니 이펙트. 약 10초, 기존 타이밍 골격 안 4~5장 자리. 플랜 B 연출 엔진·검증된 컷 재사용. **스토리보드를 장면별 소스 파일 표와 함께 먼저 사용자에게** | 사용자 |
| 2026-09-27 | 로사·로이 그림(프로젝트 자체 FRLG 화풍 자산)은 오프닝·엔딩에 사용 가능 — **예술감독이 공식 트레이너 그림과 나란히 비교해 통과시킨 경우에만** | 사용자 |
| 2026-09-27 | 에메랄드 인게임 그래픽의 오프닝 사용 허용 | 사용자 |
| 2026-09-27 | `reference/`(애니 클립·공식 오프닝 영상) git 제외 유지. 그 프레임은 배포물·문서·공략집 어디에도 넣지 않는다 | 사용자 |
| 2026-09-27 | 성도 엔딩 새 곡: 성도 본 작업 착수가 결정될 때까지 보류 | 사용자 |
| 2026-09-27 | 호연 3단계는 구역(미로마을 → 이끼시티 → 금탄시티)이 끝날 때마다 사용자에게 보고 | 사용자 |
| 2026-09-27 | 타이틀 대안 시안 4장을 `docs/team/title/`로(A·B·비교·반려된 일러스트 v2). 사용자가 보고 결정 | 사용자 |
| 2026-09-27 | **오프닝 스토리보드 A 승인**(`docs/anim/storyboard-A/`). 예술감독 2판 수정 4건(아래 구름 레이어 위상 반 주기 오프셋 · 2차 낙뢰 때 피카츄·라이츄 접촉부 정리 · 승리 컷 레드와 피카츄를 한 쌍으로 · 흔들림 시 검은 가장자리 없음)을 반영해 게임에 구현. 구현 캡처는 예술감독 나란히 비교 → 사용자 미리보기 뒤 병합 | 사용자 |
| 2026-09-27 | 오프닝 길이·음악: 원작처럼 `MUS_INTRO_FIGHT` 9마디를 끝까지 울린다(약 12.5초) | 사용자 |
| 2026-09-27 | 미로마을 두 집: 한 집은 원작대로 **오달박사 가족**(라이벌 거주), 다른 한 집은 칸토에서 온 주인공을 재워 주는 **하숙집 가족**(새 설정). 하숙집 침대에서 휴식·회복 → 호연 거점 | 사용자(기획 Q1 대신) |
| 2026-09-27 | 103번 도로 라이벌: 원작대로 배틀 후 연구소로 돌아간다(103번에서 숨김, 연구소에 등장) | 사용자(기획 Q2) |
| 2026-09-27 | 오프닝 A 게임 구현본 사용자 확인("이게 차라리 낫다") → `hoenn-z3`에 병합, v0.11.0에 포함(v0.11.1 단독 불필요) | 사용자 |
| 2026-09-27 | ROXANNE 전투 중 도발은 전투 뒤 대사로(엔진 추가 없음) · 흰 허브 꽃집 아가씨는 조건 없이 항상 등장 | 사용자 "추천대로" |
| 2026-09-27 | **타이틀: 레이아웃 B**(PRESS START 위 노란 띠, 파란 하늘 전체) · **볼 색 연한 주홍**(예술감독 권고 200,80,40 부근). 전기 이펙트 애니메이션(비트에 맞춘 팔레트 발광·섬광)까지 구현 → 예술감독 → GIF 미리보기 → 사용자 승인 뒤 병합 | 사용자 |
| 2026-09-27 | **타이틀 재개편(앞의 B안·대안 스프라이트 결정을 대체)**: FR/LG 일본판 타이틀(리자몽·이상해꽃) 구성·색 처리를 따라 **피카츄를 노란 단색조 대형 전신 전투태세로 새로 그린다**. 강조=볼·몸의 전기(흰~연노랑), 스파크 입자 부유, 파란 단색 배경+천천히 흐르는 번개 줄무늬. 몸통 BG 고정, 귀 끝·꼬리·볼 2~3프레임, 스파크 스프라이트, 팔레트 순환 발광, BGM 강박에 화면 플래시·큰 방전. 레이아웃은 현재 유지안 + PUSH START 상단 바 안 비교. 240×160·16색·VRAM 예산·실기 프레임 드롭 없음. 정지 초안 → 예술감독 → PNG 사용자 → 승인 뒤 애니메이션 → GIF(BGM 타이밍 표시) → 사용자 승인 전 게임에 넣지 않음. 참고 화면은 복사 금지. (지정 경로 `docs/reference/frlg-title-reference.png`는 없어 `reference/FRLG Opening.jpg`와 저장소의 공식 FR/LG 타이틀 그래픽을 참고로 씀) | 사용자 |

## 대기 중인 일

- **v0.11.0 호연 Z3**(계획 승인, `docs/v0.11.0-plan.md`): 에메랄드 곡 이식·누락 스토리 캐릭터 복원 포함. 착수 대기
- **오프닝**: 구현 완료, `hoenn-z3`에 병합. 릴리스 전 QA 실시간 시청
- **타이틀**: 재개편 — 단색조 전신 피카츄 정지 초안(일러스트레이터) → 예술감독 → 사용자 PNG
- 음악: 새 곡 후보는 성도 엔딩뿐 — 성도 착수 결정까지 보류
- 성도 전제 조건: 호연 Z4~Z7 중 여유 있을 때(착수는 호연 완료 후)

## 저장 자원 예약

| 자원 | 용도 | 계획서 |
|---|---|---|
| hoennFlags `HOENN_FLAGS_START+0x780`~`+0x79F` | 스내그: 라이벌 13칸·로사·로이 6칸 진화 계열 기록 | v0.10.0 |
| BoxPokemon `unused` 비트 1개(isStarterPikachu 옆) | isSnagged | v0.10.0 |
| hoennFlags 스토리 +52·+53 | 트릭하우스 최종 상품 두 개(부적금화·학습장치) 기록 | v0.9.0 (사용 중) |
| hoennFlags 스토리 **+54~+96**(원래 +52~+94에서 두 칸 밀림), hoennVars 0x24~0x28 | 호연 Z3 | v0.11.0 |
| hoennFlags `0x500`~`0x77F`(640비트, 마스터 플랜 8.2의 `0x500~0x7FF`에서 스내그 예약과 겹치는 끝을 잘라냄) | 성도 전용 블록(필요 약 300비트) | 성도 J1~ |
| 필드 오브젝트 그래픽 번호 235~239(남은 5칸, `graphicsId`는 u8·세이브 안) | 성도 인물 약 22명은 "지역 뱅크"(성도 맵 그룹에서만 호연 전용 번호를 성도 그림으로 읽기) 시범 뒤 결정 | 성도 G1 |

## 기준선

| 날짜 | 대상 | 결과 |
|---|---|---|
| 2026-09-24 | v0.8.0 코드, `mapsmoke.py -j 2`(선두 Lv100·스프레이, 오브젝트 전부 화면 통과) | **896/896 OK** |
| 2026-09-24 | v0.8.0 코드, `savetest_all.sh` | 5종 OK (load IDENTICAL) |

## 2026-10-02 — Airport indoor window foreground fix (Codex)

Applied and built the window foreground priority fix in event_object_movement.c. Player, NPC and follower remain in front of the glass while the exterior plane stays behind its frame. Airport 14/14, six legacy saves and three user-save runtime scenes pass; all seven original top-level saves unchanged. Evidence: docs/team/qa/codex-airport-window-20261002/QA.md. No commit/push/release. Animation/title/Rocket art, regional endings and expansion/storage backlog remain open; this result does not mark them complete.


## 2026-10-02 - Route116 DEVON repeat-ball reward (Codex)
Restored the employee at (46,11) and the approved E12 reward after DEVON recovery. Nine cases, existing DEVON regression, six legacy save compatibility checks, Route116 map smoke, map integrity, text width and dex checks passed. All saves and unrelated changes were preserved; canonical patch reapplication is idempotent. Existing warning baseline remains. Evidence: docs/team/qa/codex-route116-repeat-20261002/QA.md. No commit/push/release.


## 2026-10-05T11:40:07.749896+00:00 — Native V8, approved opening and regional dex integration

Main LEAFGREEN pokemonthyl.gba now contains title V8 (exact user Lightening.png, native original Pika voice), approved opening-full-frlg-v7 pixels with MUS_INTRO_FIGHT and V11 Jessie/James game-size64 graphics. Native title40-frame ROI comparison and voice START/A passed; all752 opening frames/palettes matched with zero drops; A/START/SELECT skip passed. Story regional dex151/251/202 UI and save/reload passed without save layout changes; 6 legacy battery saves load. Original v1.2 and all saves unchanged. Existing Bad Egg preserved, not fabricated as repaired.

Rusturf Wanda reunion source canonicalized; review build passed, 11/11 native event cases and3/3 map smoke passed; main rebuild pending. Old/current Kanto scroll360 frames:277/278 task callbacks respectively (existing cost, no added-regional-dex regression). Tile-row scroll candidate awaiting native byte/performance tests. Johto full story and Hoenn League still incomplete; assigned in parallel. No push/deploy. Evidence: outputs/rom-integrated-v8-20261005T111752Z/rom-provenance.json, outputs/regional-dex-story-v1 and outputs/rusturf-wanda-reunion-v1.

## 20261005T125922Z native region integration
Validated ROM b3b62a31d4a7543876322d3e92947be6516e387f3c2035e834daa05551b19dfc; thirteen Johto maps, Rusturf/Wanda, Hoenn badges7/8 and league/HOF/credits/checkpoints integrated. Native five wins/loss, north/south checkpoint and HOF cold reload preserve party/PC/dex and all original saves. Save ABI unchanged; compatible v1.2 delivery is byte-identical, existing damaged box record not repaired. Full Johto/Hoenn story remains incomplete; Violet chapter pending. Dex glyph552/icon240 byte tests pass; DOWN46/UP13 missed task frames remain. Delivery: /workspaces/pokefirered/outputs/rom-regions-update-20261005T125922Z

## 20261005T133114Z native region integration
Validated ROM db5a29af95d648cc2c114c34a2c1e2e62d7d96b349eb4bfb0ef04a4302a59e56; twenty-three Johto maps, Rusturf/Wanda, Hoenn badges7/8 and league/HOF/credits/checkpoints integrated. Native five wins/loss, north/south checkpoint and HOF cold reload preserve party/PC/dex and all original saves. Save ABI unchanged; compatible v1.2 delivery is byte-identical, existing damaged box record not repaired. Full Johto/Hoenn story remains incomplete; Violet chapter native Li/Falkner wins/loss, native saves/cold reload, 10 map smoke tests, 16 habitat species, 11 clock cases/144 generated records pass. Azalea pending. Dex glyph552/icon240 byte tests pass; DOWN17/UP11 missed task frames remain after native whole-tile aligned window fill optimization. Delivery: /workspaces/pokefirered/outputs/rom-regions-update-20261005T133114Z

## 2026-10-12T12:51:27.243139+00:00  Regional followup scoped repair

Route114 TM05 actual reward and success-only local receipt canonicalized through patches and applied idempotently. Johto League-cleared airstrip clerk adds onward research guidance while existing flight stays. Exact ROM f31b2eea1ae45fd1dd40057c80510a8875936394e5807d00806a90cff1dee73d native7/eventcheck3/map2/legacy6+user2 loads pass; original14 SAV unchanged, approved24 assets and SaveABI preserved. Host paired600-frame comparisons show no sustained slowdown criterion; actual DELTA device not tested. Whole campaign/N/space/three endings remain incomplete; global80dead+14promises and Route11442 original texts remain. Existing Lickitung Bad Egg is not repaired. Capture comparison passed on previousb46 only; not a DELTA cause proof. Local main updated with rollback, no push/public release. Evidence: /workspaces/pokefirered/docs/team/qa/codex-regional-followup-20261012/QA.md

### 2026-10-13  1.25 IV/   ROM   

 99,  /// IV 31  SAV. nativeSAVE/cold  /byte . 457quick456OK+darkroom1 , 457 . /  .  docs/team/qa/codex-save-hoenn-review-20261013/QA.md. ROM f31 , SAV   .

### 2026-10-13 Native verification follow-up

Current f31/v1.25: 36000 idle frames, state load return/frame/RNG proof, 16 Pika/21 Misty water/land samples, Johto professor 151->251, eligible Hoenn 202 UI, two lab door/cold chains, five exact list/seen/caught checks. Inputs preserved. No product ROM changes. Full campaign/DELTA/old BadEgg recovery remain pending. Evidence: docs/team/qa/codex-verification-followup-20261013/QA.md.


2026-10-13T04:21:09.440778+00:00 Regional starters: six gift events use IV31, Johto repeat assistant sequence, canonical scripts synchronized. 32 native cases pass on 63904802b37dc5e922ec616361c0be3388f1030e5b2c1a0b7a2949f2a33c1f7c. Main ROM promoted; 10 SAV files unchanged. Scope excludes full campaign, DELTA device and existing BadEgg recovery. Evidence: work/regional-starters-20261013/validation-final.json
