"""Compile/run the isolated host C baseline/candidate, preserving product inputs.

No emulator, guest RAM writes, product build, source edits or State restoration.
HOST interfaces are stubbed; the result is not a native GBA capture proof.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import traceback

SOURCES = {'baseline.c':'7055c63e78fb2d23251191fdfcb93b3dc15c7cce0891479a2e382fc12b919235',
           'candidate.c':'0562cbbf1847c659bcf2e1e62e7e42398fa142725eee1ac0aecbf16eef914cbc'}
ROM_SHA = 'af2677993a75979fb36f0768c390d1bad7424e61f2d569b5054d40702250d2e8'
SAV_SHA = 'c06ad0536f1ee13fd88a3cf36346b52d3d5ca0cae7e729723acf6047d916feb8'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    for name in ('root','rom','sav','out'):
        p.add_argument('--'+name,required=True,type=Path)
    p.add_argument('--cc',default='gcc')
    cfg=p.parse_args()
    root=cfg.root.resolve(strict=True)
    rom=cfg.rom.resolve(strict=True)
    sav=cfg.sav.resolve(strict=True)
    out=cfg.out.resolve()
    assert out.is_relative_to(root/'work') and not out.exists()
    bundle=Path(__file__).resolve().parent
    assert sha(rom)==ROM_SHA and sha(sav)==SAV_SHA
    for name,digest in SOURCES.items():
        assert sha(bundle/name)==digest
    compiler=shutil.which(cfg.cc)
    assert compiler,'Existing host gcc is unavailable; no installer is permitted'
    protected={p:sha(p) for p in set((root/'saves').rglob('*.sav')) | {rom,sav} |
               {bundle/name for name in SOURCES}}
    out.mkdir(parents=True)
    result=dict(schema='thunder-yellow-HOST-capture-PP-regression-v1',pass_all=False,
                ROM_sha256=ROM_SHA,SAV_sha256=SAV_SHA,source_bundle_sha256=SOURCES,
                original_inputs_unchanged=False,native_GBA_capture=False,
                DELTA_State_tested=False,BadEgg_cause_proven=False,
                guest_RAM_writes=0,product_source_changes=0,cases=[])
    try:
        for name in SOURCES:
            candidate=name=='candidate.c'
            executable=out/('candidate-host-test' if candidate else 'baseline-host-test')
            cmd=[compiler,'-std=c11','-O0','-Wall','-Wextra','-Wno-pointer-to-int-cast',
                 '-Wno-misleading-indentation','-Wno-unused-but-set-variable',str(bundle/name),'-o',str(executable)]
            compiled=subprocess.run(cmd,text=True,capture_output=True,timeout=45)
            (out/(name+'.build.log')).write_text(compiled.stdout+compiled.stderr,encoding='utf-8')
            assert compiled.returncode==0,compiled.stderr
            assert 'warning:' not in compiled.stderr,compiled.stderr
            ran=subprocess.run([str(executable)],text=True,capture_output=True,timeout=15)
            (out/(name+'.run.log')).write_text(ran.stdout+ran.stderr,encoding='utf-8')
            assert ran.returncode==0,dict(stdout=ran.stdout,stderr=ran.stderr,code=ran.returncode)
            row=json.loads(ran.stdout)
            assert row['host_component_pass'] and row['cases']==9 and row['candidate']==candidate
            assert not row['native_GBA_capture'] and not row['BadEgg_cause_proven']
            result['cases'].append(row)
        result.update(pass_all=True,status='HOST_COMPONENT_PASS_NATIVE_PENDING',
            meaning='Real extracted source transfer/PP functions reproduce stock PP on first baseline enemy-address PC transfer and yield owner floor after the one-line candidate. This is a host C harness with stub data/storage interfaces.',
            candidate_deployed=False,actual_emulator_capture_required=True)
    except Exception as error:
        result.update(status='FAILED',error=repr(error),traceback=traceback.format_exc())
    finally:
        result['original_inputs_unchanged']=all(sha(p)==h for p,h in protected.items())
        assert result['original_inputs_unchanged']
        (out/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
    raise SystemExit(0 if result['pass_all'] else 1)


if __name__=='__main__':
    main()
